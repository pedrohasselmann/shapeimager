# -*- coding: utf-8 -*-
#!/usr/bin/python
from __future__ import print_function, unicode_literals, absolute_import, division

doc = '''
  #########################################################################################
  #  author: Pedro H. Hasselmann, Rio de Janeiro (LESIA-OBSPM/ON-MCT)
  #  script: shapemodel.py
  #
  # Shape Model Manipulation
  #
  # Load .OBJ, .PLY, .VER shape model.
  #
  # Requirements:
  # numpy, scipy, astropy, pandas, skimage, matplotlib
  #
  ##########################################################################################
'''
from source import *

###############################################################################
############################ SHAPE MODEL TOOL #################################
class ShapeModel(object):

  def __init__(self,shapefile, comments=0):
    import itertools
    from glob import glob
    from numpy import float32, int32, array, split, savez, load, unique
    
    npz = path.join(home,aux,shapefile.split('.')[0]+'.npz')
    shapefile = path.join(home,aux,shapefile)
    print(shapefile)
    self.shapefile_ = shapefile
    print(npz)

    if len(glob(npz))==1:
      with load(npz, allow_pickle=True) as f:
          self.vertices_ = f["vertices"]
          self.facets_   = f["facets"]
          self.array_    = f["array3D"]
          self.facet_index_ = f["facet_index"]

    else:
      if shapefile[-3:] == 'obj':
        self.load_obj(shapefile, comments)
    
      if shapefile[-3:] == 'ply':
        self.load_ply(shapefile)
    
      if shapefile[-5:] == 'shape':
        self.load_sha(shapefile)

      if shapefile[-3:] == 'ver':
        self.load_ver(shapefile)

    if len(glob(npz))==0:
      # Final database format : 3D-array packing all triangle vertices
      vertices = pd.DataFrame(self.vertices_, index=range(self.vertices_.shape[0]), columns=['X','Y','Z'])
      df = vertices.loc[self.facets_.ravel()]
      df['facet_index'] = list(itertools.chain.from_iterable(itertools.repeat(x, 3) for x in range(self.facets_.shape[0])))
      df.set_index('facet_index', inplace=True)
      #print(df.loc[0])
      self.facet_index_ = unique(df.index)+1
      self.array_ = array(split(df.values, len(self.facet_index_)), order='C', dtype=float32)
    
      savez(npz,
          vertices=self.vertices_,
          facets=self.facets_,
          array3D=self.array_,
          facet_index=self.facet_index_)

    print('shape model is loaded......',self.vertices_.shape, self.facets_.shape)


################################
## LOAD SHAPE MODEL FUNCTIONS ##
################################

  def load_obj(self, shapefile, comments=11):
    ''' 
       Load Shape Model OBJ.
    '''
    from pandas import read_csv
    from numpy import float32, int32, split
  
    #{'names':('X','Y','Z'), 'formats':('f4','f4','f4')}
    self.vertices_ = read_csv(shapefile, dtype=float32, 
                             comment='f', usecols=(1,2,3), skiprows=comments, header=None, delim_whitespace=1).values
    #{'names':('V1','V2','V3'), 'formats':('i4','i4','i4')}
    self.facets_ = read_csv(shapefile, dtype=int32,
                           comment='v', usecols=(1,2,3), skiprows=comments, header=None, delim_whitespace=1).values -1


  def load_ply(self, shapefile):
    '''
      Load Shape Model PLY.
    '''
    from plyfile import PlyData, PlyElement
    from numpy import  array, asarray, matrix, float32, int32, split

    mesh = PlyData.read(open(shapefile, 'rb'))
    print(shapefile)
    print(mesh)

    self.vertices_ = array(map(lambda x: list(x), mesh['vertex'].data), dtype=float32)
    self.facets_   = array(map(lambda x: list(x[0]), mesh['face'].data), dtype=int32) #-1

  def load_sha(self,shapefile):
    '''
       Load Shape Model .shape
    '''
    from pandas import read_csv
    from numpy import float32, int32, split

    f = open(shapefile, 'r+')
    delimiter = int(f.readline().split(' ')[0]) -1
    mesh = read_csv(f, dtype=float32, skiprows=1, usecols=(0,1,2)).values
    
    self.vertices_ = mesh[:delimiter,:]
    self.facets_ = mesh[delimiter:,:].astype(int32)

  def load_ver(self,shapefile):
    from collections import deque
    from numpy import int32, float32, array
    
    with open(shapefile, 'r+') as f:
       N = f.readline().split("   ")
       N.remove(u'')
       N_vertices = int(N[0])
       N_facets = int(N[1])
       print(N[0], N[1])
       # Read Vertices
       V = deque()
       l=0
       while l<N_vertices:
           V.append(f.readline().split(" "))
           l+=1
    
       self.vertices_ = array(V, dtype=float32)
    
       # Read facets
       F = deque()
       k,l=0,1
       while k<N_facets:
        if l%2==0:  
          line = f.readline().split(" ")
          line=filter(lambda a: a!='', line)
          F.append(line)
          k+=1
        else:
          f.readline()
        l+=1

       self.facets_ = array(F, dtype=int32) -1

######################
## ARRAY FORMATTING ##
######################
  def rebase(self, v):
    '''
       Re-format projected vertices to facet-oriented index.
       v : coordinates per vertice - (M, N)
    '''
    import itertools
    from numpy import float64, float32, int32, array, split
    
    # Final database format : 3D-array packing all triangle vertices
    vertices = pd.DataFrame(v, index=range(self.vertices_.shape[0]))
    df = vertices.loc[self.facets_.ravel()]
    df['facet_index'] = list(itertools.chain.from_iterable(itertools.repeat(x, 3) for x in range(self.facets_.shape[0])))
    df.set_index('facet_index', inplace=True)
    #print(df.loc[0])
    return array(split(df.values, self.facet_index_.shape[0]), dtype=float64, order='C')
      

################################
## COORD FRAME TRANSFORMATION ##
################################
  def frame(self, to_SPC=True, to_CHEOPS=False):
    '''
      Transform from CHEOPS to SPC frame and vice-versa.
    '''
    from numpy import array, transpose, matrix
    
    # Rotation matrix and Translation vector from SPC to CHEOPS frame.
    R = matrix([[0.999988115010352E+00, -0.486673862742470E-02,  0.291020917157006E-03],
                [0.486651407512085E-02,  0.999987863999109E+00,  0.767395110673006E-03],
                [-0.294752096754503E-03, -0.765969732800629E-03,  0.999999663205728E+00]])  
  
    T = array([ -0.0029655, 0.0012162, -0.0169312])
    
    if to_SPC:
      self.vertices_ = (R.I*transpose(array(self.vertices_ - T))).T
  
    elif to_CHEOPS:
      self.vertices_ = (R*transpose(array(self.vertices_ + T))).T

##################
## SAVE FORMATS ##
##################

  def save_obj(self):
    from numpy import around, savetxt

    obj = open(path.join(aux,self.shapefile_[:-4]+'.obj'),'w+')

    obj.write(''.join(['##############################################\n',
            '# 3D Shape model                               \n',
            '# --------------                               \n',
            '# This mesh has been reformatted by the \n',
            '# ShapeModel.save_obj (P. H. Hasselmann, LESIA)   \n',
            '#                                             \n',
            '#                                             \n',
            '# Vertices: '+str(self.vertices_.shape[1])+' \n',
            '# Faces: '+str(self.facets_.shape[0])+'  \n',
            '#                                              \n',
            '##############################################\n']))

    #print(facets)
    savetxt(obj, around(self.vertices_, 8), fmt=str('v %2.8e %2.8e %2.8e'))
    savetxt(obj, self.facets_, fmt=str('f %8i %8i %8i'))
  
    obj.close()
    print('.obj ....OK.')

###############
## SELECTION ##
###############
  def select(self, f):
    '''
      Select facets by their index.
    '''
    self.facet_index = tuple(f)
    self.array  = self.array_[f,...]
    self.facets = self.facets_[f,...]
    print('new shape ',self.array_.shape, self.facets_.shape)

#################
## COORDINATES ##
#################

  def spherical_coords(self, pickle=False):
    '''
       Cartesian to Spherical coordinates.
    '''
    import itertools
    from numpy import float32, int32, split
        
    # Spherical coordinates
    v = self.vertices_
    lat, lon, r = spherical_coord(v[:,0], v[:,1], v[:,2])

    coords = pd.DataFrame({'lat':lat.T, 'lon':lon.T}, index=range(lat.size))
    df = coords.loc[self.facets_.ravel()]
    df['facet_index'] = list(itertools.chain.from_iterable(itertools.repeat(x, 3) for x in range(self.facets_.shape[0])))
    df.set_index('facet_index', inplace=True)
    coords = array(split(df.values, self.facet_index_.shape[0]),dtype=float32)

    self.lat_ = coords[:,:,0]
    self.lon_ = coords[:,:,1] 
    
    if pickle == True:
      self.lat_.to_pickle(self.shapefile.split('.')[-1]+'_lat.pkl')
      self.lon_.to_pickle(self.shapefile.split('.')[-1]+'_lon.pkl')

##################
## NORMAL VECTOR ##
###################

  def normal_vector(self, pickle=False):
    '''
       Compute facet centroid and normal vector.
    '''
    from numpy import array, isnan, transpose, sqrt, cross, arccos, clip, sum,  gradient, float32, int32, split, load

    shapepath = self.shapefile_.split('.')[0]

    if path.exists(shapepath+'_normalvector.pkl'):
      self.n_ = load(shapepath+'_normalvector.pkl', allow_pickle=True)
      self.tilt_ = load(shapepath+'_tilt.pkl', allow_pickle=True)
      return

    # Normal Vector in respect to the center of the facet
    der = array(gradient(self.array_, axis=1)) # Derivatives
    # Colunms X Y Z
    n = cross(der[:,0,:],der[:,2,:]) # Normal Vector
    
    # Tilt between normal vector and a vertice
    v = self.array_[:,0,:] # Vertices 1
    v = transpose(v.T/sqrt(sum(v*v, axis=1)))
    n = transpose(n.T/sqrt(sum(n*n, axis=1)))
    tilt = arccos(clip(sum(n*v, axis=1), -1e0, 1e0)) # Tilt
    tilt[tilt >= 3.1415926/2e0] = 3.1415926 -tilt[tilt >= 3.1415926/2e0]
    tilt[isnan(tilt)] = 0e0
      
    # Save into self
    self.n_ = n
    self.tilt_ = tilt

    if pickle == True:
      self.n_.dump(shapepath+'_normalvector.pkl')
      self.tilt_.dump(shapepath+'_tilt.pkl')

  def normal_vector_ellipsoid(self, axes, pickle=False):
    '''
      Compute the normal vector by replacing the local surface element tilt (facet)
      for a smooth tangent plane represented by a equivalent ellipsoid of same radius.
      
      Tangent Plane at point (x0, y0, z0):
      
      x*x0/a**2 + y*y0/b**2 + z*z0/c**2 = 1
      
      Normal vector to such plane:
      
      n = [x0/a**2, y0/b**2, z0/c**2]
    '''
    from numpy import array, isnan, transpose, sqrt, cross, arccos, clip, sum,  gradient, float32, int32, split, load

    shapepath = self.shapefile_.split('.')[0]

    if path.exists(shapepath+'_normalvectorellip.pkl'):
      self.n_ = load(shapepath+'_normalvectorellip.pkl', allow_pickle=True)
      return

    n = self.array_/axes**2
    self.n_ = transpose(n.T/sqrt(sum(n*n, axis=1)))

    if pickle == True:
      self.n_.dump(shapepath+'_normalvectorellip.pkl')

##########################
## GEOMETRIC PROPERTIES ##
##########################

  def project(self, v):
    '''
       Compute the vector and angle of shape model to a given source.
       The vector-direction must be referenced to the shape model cartesian origin.
       Thus, incidence and emergence angles may be now calculated with precision.
       
       Angles given in radians.
    '''
    from numpy import array, isnan, transpose, sqrt, cross, arccos, clip, sum, float32, float64
    assert hasattr(self, 'n_')
    
    n = self.n_
    d = self.array_[:,0,:]
    v = array(v, dtype=float64) +d
    v = transpose(v.T/sqrt(sum(v*v, axis=1)))
    #n = transpose(n.T/sqrt(sum(n*n, axis=1)))
    
    v_n = sum(n*v, axis=1).astype(float32)
    angle = arccos(clip(v_n, -1e0, 1e0)).astype(float32) # Tilt
    #angle[angle >= pi/2e0] = pi - angle[angle >= pi/2e0]
    angle[isnan(angle)] = -3.1415926/2e0    
    return angle, v_n

  def phase(self, v, o):
    '''
       Compute phase angle between two re-based vectors 'v' and 'o'.
       
       Angles given in radians.
    '''
    from numpy import array, isnan, transpose, degrees, sqrt, cross, arccos, clip, sum, \
    float32, float64
    assert hasattr(self, 'array_')

    phase_at_center = arccos(sum(transpose(v.T/sqrt(sum(v*v)))*transpose(o.T/sqrt(sum(o*o)))
                                                            )
                                                        )
    print('phase angle at body center is {: 3.3f}'.format(degrees(phase_at_center)))
    
    d = self.array_[:,0,:]
    v = array(v, dtype=float64) +d
    o = array(o, dtype=float64) +d
    
    v = transpose(v.T/sqrt(sum(v*v, axis=1)))
    o = transpose(o.T/sqrt(sum(o*o, axis=1)))
 
    v_o = sum(o*v, axis=1)
    angle = arccos(clip(v_o, -1e0, 1e0)) # Tilt
    #angle[angle >= pi/2e0] = pi - angle[angle >= pi/2e0]
    angle[isnan(angle)] = -3.1415926/2e0    
    return angle, v_o

  def distance(self, o):
     from numpy import float32, sqrt, sum
     return sqrt(sum((self.array_-o)**2, axis=1))

  def plane(self, o, n, e1=[1,0,0], e2=[0,1,0]):
    '''
       Reproject all shapemodel vertices onto a given plane.
      
       Projected vertice satisfies the relation:
       P = o + v1*e1 + v2*e2 + s*n

       s = Dot(n, v-O)
       v1 = Dot(e1, v-O)    
       v2 = Dot(e2, v-O)
       
       Parameters
       ==========
       n : vector that defines the plane
       o : origin of the plane
       
       v1, v2 : (X, Y), Cartesian coordinates of the shape model projected onto the (e1,e2) plane
       https://stackoverflow.com/questions/33658620/generating-two-orthogonal-vectors-that-are-orthogonal-to-a-particular-direction
    '''
    from numpy import float64, float32, asarray, transpose, sqrt, cross, sum, vstack
    
    n = asarray(n)
    o = asarray(o)

    # Define the base of the plane orthogonal to n (e1,e2)
    e1 = asarray(e1, dtype=float64)  # take an arbitrary vector
    #e2 = array(e2, dtype=float32)  # take an arbitrary vector

    # Normalize vectors
    n = transpose(n.T/sqrt(sum(n*n, axis=0)))
    #o = transpose(o.T/sqrt(sum(o*o, axis=0)))
    
    e1 -= e1.dot(n)*n                   # make it orthogonal to n
    e1 /= sqrt(sum(e1*e1, axis=0))      # normalize it
    e2 = cross(n, e1)

    #print('orthogonality e1',e1.dot(n))
    #print('orthogonality e2',e2.dot(e1), e2.dot(n))

    # Project onto Plane
    d = self.vertices_ -o  # Columns X Y Z (Vertices/rows 1 2 3)
    s=sum(-d*n, axis=1)
    v1=sum(d*e1, axis=1)
    v2=sum(d*e2, axis=1)

    # Re-format the plane-projected shape model to facet-oriented index.
    v1_v2 = self.rebase(vstack([v1, v2]).T)
    s = self.rebase(s)

    return v1_v2, s, (-n, e1, e2)

  def camera_framing(self, R, n, o):
    '''
       Re-project the 3D shape model onto the camera perspective.
    
       http://ksimek.github.io/2012/08/22/extrinsic/
       
       Parameters
       ==========
       R : Camera Rotation matrix (numpy.array, 3x3)
       n : Boresight vector (numpy.array, 1x3)
       o : camera origin vector (numpy.array, 1x3)
    '''
    from numpy import int32, float32, transpose, sqrt, median, argmax, fabs, sum
    from math import fabs

    # boresight
    #f = sqrt(sum(n*n, axis=0)) #focal length
    #nn = transpose(n.T/f)
    
    # Intrinsic Matrix
    f =  n[2]
    y0 = n[1]
    x0 = n[0]
    K = array([[ f,   0,   x0],
               [ 0,   f,   y0],
               [ 0,   0,   1]], dtype=float32)

    # Extrinsic Matrix
    d = (self.vertices_ -o).copy(order='C')
    X = K.dot(R.dot(d.T))
    
    # Re-format the plane-projected shape model to facet-oriented index.
    i=(1,0)
    j=2
    v1_v2 = self.rebase((X[i,:]/X[j,:]).T)
    d = self.rebase(X[j,:])
    
    return v1_v2, d


  def irradiance(self, Sw, s, o):
     '''
       Irradiance at the instrument distance
       
       Input
       =====
       Sw : Source spectral irradiance at given wavelength at source position
     '''
     from numpy import float32, transpose, sum, sqrt
     source_at_obs = sqrt(sum(o**2))*transpose(s.T/sqrt(sum(s**2)))
  
     # SHAPE MODEL
     # Area projection & solid angle
     v1_v2, d, base = self.plane(source_at_obs, s)
     solid_angle_inc_ =  solid_angle_tri(v1_v2/d, 1e0)
     return float32(Sw)*solid_angle_inc_






####################
### PARTITIONING ###
####################
  def partitioning(self, dlat=5, dlon=5, dxy=0.020, dz=0.100, pole=(-90,90), save=False, mode='yield'):
    '''
       Partitioning the shape model in equal block.
       The blocks may intercept and have variable local surface sizes.
       https://math.stackexchange.com/questions/225614/tangent-plane-to-sphere
       https://stackoverflow.com/questions/37670658/python-dot-product-of-each-vector-in-two-lists-of-vectors
        
        P4____________P5
     P0 /|           /|
       x-|----------x P1
       | |          | |
       | |          | |
       | |   x      | |
       | |____N ____|_|
       |/ P6        |/ P7
       x------------x
     P2              P3

       Tangent Plane: 2(x-xp) + 2(y-yp) + 2(z-zp) = 0
       Normal vector (x, y, z)
       https://math.stackexchange.com/questions/2679926/unit-normal-of-sphere-in-cartesian-coordinates
       http://citadel.sjfc.edu/faculty/kgreen/vector/Block3/flux/node6.html


       Two modes:
       yield : return generator. Output: (corners, box_content)
       return : charge (base, cartesian, corners, box_content) into self.patches

    '''
    from numpy import int32, float32, isnan, arange, meshgrid, where, sin, cos, array, logical_and, \
    sqrt, cross, transpose, sum, zeros, ones, einsum, radians, stack, vstack, fabs, dot, all, savez
    from numpy import linalg
    from scipy.interpolate import griddata
    from collections import deque
    #print(self.vertices_.max(0))
    #print(self.vertices_.min(0))

    #cart_array = self.vertices_
    lat, lon, r = array(spherical_coord(self.vertices_[:,0], self.vertices_[:,1], self.vertices_[:,2]), dtype=float32)
    #print(lat.max(), lat.min())
    #print(lon.max(), lon.min())

    # Grid -- Correct
    glat = radians(arange(pole[0],pole[1],dlat))#[1:]
    glon = radians(arange(-180,180,dlon))#[1:]
    glat, glon = meshgrid(glat, glon)
    gr = griddata(array((lat,lon)).T,r,(glat,glon), method='nearest')

    # Spherical to Cartesian -- Correct
    x = gr*cos(glat)*cos(glon)
    y = gr*cos(glat)*sin(glon)
    z = gr*sin(glat)
    #print(x.max(), x.min())
    #print(y.max(), y.min())
    #print(z.max(), z.min())
    # Normal Vectors -- Correct
    xyz = vstack((x,y,z)).reshape(3, -1)
    n = xyz/sqrt(sum(xyz*xyz, axis=0))

    # Orthogonal base -- Correct
    dim = n.shape[1:]
    e1 = vstack((zeros(dim), zeros(dim), ones(dim))) # vector parallel to longitude line
    e1 -= einsum('ij, ij->i', e1.T, n.T)*n   # make it orthogonal to n (einsum: multidimensional dot operation)
    e1 /= sqrt(sum(e1*e1, axis=0))            # normalize it
    e2 = cross(n.T, e1.T).T                   # vector parallel to latitude line
    e2 /= sqrt(sum(e2*e2, axis=0))            # normalized it

    # Continue....
    # Partitioning shape model vertices into boxes
    #Box ---  dX dY dZ
    corners  = array((( dxy, dxy, dz),
                      (-dxy, dxy, dz),
                      ( dxy,-dxy, dz),
                      (-dxy,-dxy, dz),
                      ( dxy, dxy, -dz),
                      (-dxy, dxy, -dz),
                      ( dxy,-dxy, -dz),
                      (-dxy,-dxy, -dz)), dtype=float32)

    # Rotation Matrix from Global frame to "surface frame"
    B0 = array(((1,0,0),
                (0,1,0),
                (0,0,1)), dtype=float32)
    #print(corners)
    corners_global = deque()
    matrix2local = deque()
    for j in range(n.shape[1]):
       B1 = vstack((e2[:,j],e1[:,j],n[:,j]))
       # Global --> Local
       M1 = linalg.solve(B1,B0)
       # Local --> Global
       M2 = linalg.solve(B0,B1)

       corners_global.append(dot(M1, corners.T).T + xyz[:,j])
       matrix2local.append(M2)

    corners_global = array(corners_global, dtype=float32)
    matrix2local = array(matrix2local, dtype=float32)

    # Binning the shape model:
    N_boxes = matrix2local.shape[0]
    print(N_boxes, ' patches')
    patch_content = deque()
    #del self.vertices_, self.facets_
    for m in range(N_boxes):
      
      M = matrix2local[m,...]

      v = self.array_ -xyz[:,m]
      p = dot(M.T, v.T).T

      boxyz = all((p[...,0]<dxy)&(p[...,0]>-dxy)&(p[...,1]<dxy)&(p[...,1]>-dxy)&(p[...,2]<dz)&(p[...,2]>-dz),axis=1)

      if mode == 'return':
        patch_content.append(self.facet_index_[boxyz])

      yield M, self.facet_index_[boxyz]

    if (save == True)&(mode=='return'):
      savez(self.shapefile_.split('.')[0]+'_patch{}_{}_{}_{}.npz'.format(dlon,dlat,dxy,dz), corners=corners_global, patches=patch_content)
      
    if mode == 'return':
      self.patches = ((e1, e2, n), xyz, corners_global, patch_content)
    


# END
