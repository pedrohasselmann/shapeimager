# -*- coding: utf-8 -*-
#!/usr/bin/python

################################################
#  Structuralize Data for Facets manipulation. #
################################################

__version__="1.0.0"

__doc__='''
  ############## Structuralize Data for Facet manipulation #######################
  ### Author: Pedro H. A. Hasselmann
  ### Last modified: March, 2016
  ### 
  ### main module for structuralizing data to HDF5
  ###
  ### Input Data structure:
  ###
  ### OASIS s_ and g_ files
  ### RAW Images (level3 or level 3B)
  ###
  ### Output Data structure:
  ###
  ### Pandas.Dataframe
  ### pkl dictionary
  ###
  #################################################################################
'''    
#from source import *

#############################################################################
############################ BINNED DATACUBE ################################
#############################################################################
def binning(store, 
                  title='binned', 
                  query="IF>0.0 and IF<0.5 and inc<1.57 and emi<1.57",  
                  nbin=(10, 10, 10),
                  per_limit=99.5,
                  **args):
  '''
     Take the illumination angles and split them up into grid. 
     The average I/F for each emi-inc-phase box is then calculated.
     Store-wise (Each entry is one image data) structure.
     
     images    --> str: hd5 store or list of strings: filenames
     query     --> Remove facets in undesired conditions.
     nbin      --> Size of bins for each angle.
     per_limit --> highest limit for luminance angles.
  '''
  from numpy import float32, std, array, meshgrid, sum, amax, amin, mean, histogramdd, arange, radians, degrees
  from scipy.stats import binned_statistic_dd, scoreatpercentile
  import pandas as pd

  # Structure: HDF5
  if (type(store) == unicode) or (type(store) == str): 
    facet_data = pd.HDFStore(path.join(prod,store+".h5"))
    images = map(lambda x: x[1:], facet_data.keys())
    print(facet_data)

  # Structure: Pandas.Panel
  else:
    facet_data = store.transpose(2,1,0)
    images = facet_data.axes[0]
    print(facet_data)

  binned = dict()
  pha  = dict()
  for n, image in enumerate(images):

    if 'facet_data' in locals():
      data = facet_data[image].query(query)
      
    else:
      data = unpickle(path.join(folder,image))[0]
      image = image.split("_")[-4]
      
    print('\n',n, image)
    #print(data)

    # Upper limit
    upper = scoreatpercentile(data[['inc','emi','phase']], per= per_limit, axis=0)
    low   = scoreatpercentile(data[['inc','emi','phase']], per= 0.0, axis=0)

    print('angle resolution (degrees): ', degrees((upper-low)/array(nbin)))

    data = data.loc[(data.emi<upper[0])&(data.inc<upper[1])&(data.phi<upper[2])].dropna(how='any')
    
    if data.shape[0] != 0:
    
      # Calculate the mean IF for each bin and return their edges
      bin, edges, locator = binned_statistic_dd(data[['inc','emi','phase']].values, data["IF"].values, bins=nbin, statistic=str("median"))
      count = binned_statistic_dd(data[['inc','emi','phase']].values, data["IF"].values, bins=nbin, statistic=str("count"))[0]
      #dev = binned_statistic_dd(data[['inc','emi','phase']].values, data["IF"].values, bins=nbin, statistic=std)[0]
    
      # central point of each bin
      central_point = [ array([sum(edges[n][i:i+2])/2.0 for i in xrange(0, len(edges[n]))])[:-1] for n in xrange(0,len(nbin)) ]
      mesh = meshgrid(*central_point, indexing='ij')

      # Save binned data in a pandas.DataFrame
      binned[image] =  pd.DataFrame({'inc'  :   mesh[0].ravel().astype(float32),
                                     'emi'  :   mesh[1].ravel().astype(float32),
                                     'phase':    mesh[2].ravel().astype(float32),
                                     'IF'   :    bin.ravel().astype(float32),
                                     #'std' :   dev.ravel().astype(float32),
                                     'n' :  count.ravel().astype(int)
                                   }, index=range(bin.ravel().size)).dropna(how='any')

      binned[image]['phi'] = phase(binned[image]['inc'], binned[image]['emi'], binned[image]['phase'])
      pha[image] = data['phase'].median()
    
      # print informations
      print('size (cells): ', binned[image].shape)
      print('phase angle range: ', binned[image]['phase'].apply(degrees).min(), binned[image]['phase'].apply(degrees).max())
      print('phase angle: ', data['phase'].apply(degrees).median())
    
      # Plot Binsize distribution:
      if args['display']:
        import matplotlib.pyplot as plt
        plt.hist(binned[image]['n'], normed=False, bins=200)
        plt.xlabel('Cell size')
        plt.xlabel('Number of bins with such size')
        plt.show()
        plt.clf()
  
  if type(store) == str: facet_data.close()
  # Dictionary of DataFrames, not Panel yet
  pickle(path.join(prod,title+'_'+obj+'_'+fi+'_bin'+str(nbin[0])+'x'+str(nbin[1])+'x'+str(nbin[2])), binned, pha)
  return binned, pha


##################################################################
######################### HDF5 STORE #############################
##################################################################

def IF_facet(x):
   from numpy import sum
   if x[8::3]:
     return sum(array(x[8::3]) * array(x[9::3])) / sum(x[8::3])

def facet_std(x, axis=0):
   from numpy import average, sqrt   
   values = array(x[9::3])
   weights = array(x[8::3])    
   N = values.shape[0]
   if x[8::3] and N > 1:
     avg = average(values, weights=weights, axis=axis)
     return sqrt(average(((values - avg)**2), weights=weights, axis=axis)*(N/(N-1.0)))
   else:
     return 0.0

def store_oasis_geometry(image_list, zip_file, query="IF>0.0 and IF<0.5 and inc<1.32", **args):
   ''' Store into HDF5 the OASIS geometry and I/F for facet on given images (img_list).
       I/F is calculated by solid-angle weighted average of pixels contained inside the facet.
       Data structure in Pandas.DataFrame.

       Parameters
       ==========
        img_list              --> List of images to be loaded from 'folder'.
        zip_file              --> Zipfile containing s_ and g_ files of the demanded images.
        points                --> Minimum number of times a facet must be present in all images.
        query                 --> Select facets at arbitrary observational conditions.
        region                --> Select only a region of the object: list of facets contained in.
   '''
   import pandas as pd
   from numpy import int32, float32, mean, median, radians, array

   store = pd.HDFStore(path.join(prod,obj+'_'+fi+'.h5'))
   pd.set_option('io.hdf.default_format','table')

   c = collect(1)
   for img in image_list:

      print(img)

      ret = Retrieve(img, zip_file, channel=args['channel'])
      facets = ret.all_facets(**args)
      
      # Facet index
      aindex = array(facets.keys()).astype(int32)          
      #aindex = aindex.astype(int32, copy=False)
      
      print('number of active facets: ', aindex.shape[0])
      
      npixels = array( map(lambda x: len(x[8::3]), facets.itervalues()) )
      
      # IF per facet: 
      #rf = sum(rk * solid_angle) / sum(solid_angle)         
      IF = pd.Series( map( lambda x: IF_facet(x), facets.itervalues()), index = aindex )
      # IF standard deviation per facet:
      IF_std = pd.Series( map( lambda x: facet_std(x), facets.itervalues()), index = aindex)
    
      print('I/F per facet computed.')
      
      # Scattering Angles
      angle = radians(array( map(lambda x: x[4:7], facets.itervalues()) ))
      
      # Lum. Latitude
      #latitude = cos_illum_lat(angle[:,0], angle[:,1], angle[:,2])
      
      # Phase Angle
      phase_angle = phase(angle[:,0], angle[:,1], angle[:,2])
      
      # Facet-Observer Distance
      dist = array( map(lambda x: x[0], facets.itervalues()) )
      
      del facets

      # Build Data Frame
      facet_info = pd.DataFrame({"inc"   : angle[:,0].astype(float32),
                                 "emi"   : angle[:,1].astype(float32),
                                 "phi"   : angle[:,2].astype(float32),
                                 "phase" : phase_angle.astype(float32),
                                 "IF"    : IF.astype(float32),
                                 "IF_std": IF_std.astype(float32),
                                 "npix"  : npixels.astype(int32),
                                 "dist"  : dist.astype(float32),
                                  }, index=aindex).query(query)

      # Instead of using all facets, select only a sample of them
      if 'region' in args: facet_info = facet_info.ix[array(args['region'])]

      store.append(img.split("_")[-5], facet_info, format='table', data_columns=True, complib=str('blosc'), complevel=8)
      
      c.next()
      print(img.split("_")[-5])
      print(store[img.split("_")[-5]].describe())
    
   print(store)
   store.close()
   #pickle(path.join(prod,obj+'_'+fi), store)


def store_from_images(img_list, geom_list, channel, query='IF<0.9 and IF>5e-4 and emi<1.4 and inc<1.4', dpi=(2048,2048),**args):
  ''' 
     Store into HDF5 the FITS images containing incidence, emergence, phase and azimuth angles
     together with the distance and averaged I/F.
     Table index is given by the facet ID.
     
     Parameters
     ==========
     img_list          --> list of images to be loaded from 'folder'.
     geo_list          --> timestamp of georeferenced simulated images.
     channel           --> index at which the image is stored in the multiwavelength cube.
     query             --> Select facets at arbitrary observational conditions.
     dpi               --> 2d image dimensions
  '''
  from numpy import int32, float32, array, arange, radians, degrees, isnan, arctan2, sqrt
  import pandas as pd

  store = pd.HDFStore(path.join(prod,obj+'_'+fi+'.h5'))
  pd.set_option('io.hdf.default_format','table')

  if all([img[0].split("_")[-4] == img[1].split('_')[-4] for img in zip(sorted(img_list), sorted(geom_list))]) is True:
    print("it's matching.")
  else:
    print("it's not matching.")
    return

  c = collect(1)
  for img in zip(sorted(img_list), sorted(geom_list)):

    print(img[0])
    print(img[1].split('_')[-4])
    print(img[0].split("_")[-4])
    if img[0].split("_")[-4] == img[1].split('_')[-4]:

      image_index = arange(dpi[0]*dpi[1], dtype=int32)

      # Pixel cartesian coordinates [facet_index != 0]
      X = read_image(img[1][:-5]+'x.fts', 0).data.byteswap().newbyteorder().ravel().astype(float32)
      Y = read_image(img[1][:-5]+'y.fts', 0).data.byteswap().newbyteorder().ravel().astype(float32)
      Z = read_image(img[1][:-5]+'z.fts', 0).data.byteswap().newbyteorder().ravel().astype(float32)

      # Build Pandas.Dataframe
      facet_info = pd.DataFrame({'inc'  : read_image(img[1][:-5]+'i.fts', 0).data.byteswap().newbyteorder().ravel().astype(float32),
                                 'emi'  : read_image(img[1][:-5]+'e.fts', 0).data.byteswap().newbyteorder().ravel().astype(float32),
                                 'phase': read_image(img[1][:-5]+'p.fts', 0).data.byteswap().newbyteorder().ravel().astype(float32),
                                 'dist' : read_image(img[1][:-5]+'d.fts', 0).data.byteswap().newbyteorder().ravel().astype(float32),
                                 'facet': read_image(img[1][:-5]+'t.fts', 0).data.byteswap().newbyteorder().ravel().astype(int32),
                                 'IF'   : read_image(img[0],        channel).data.byteswap().newbyteorder().ravel().astype(float32),
                                 'lat'  : degrees(arctan2(Z, sqrt(X**2 + Y**2))),
                                 'lon'  : degrees(arctan2(Y, X))
                                 }, index = image_index).query('facet != 0').query(query)

      print(facet_info.columns)
      # Azimuth
      facet_info['phi'] = azimuth(facet_info['inc'],facet_info['emi'],facet_info['phase']).astype(float32)
      # Group I/F measurements regarding the same facets
      #facet_info = facet_info.reset_index().groupby('index')
      # i/F standard deviation
      #IF_std = facet_info.std()['IF']
      # Collapse the grouping
      #facet_info = facet_info.median()
      #facet_info['IF_std'] = IF_std

      # HDF5
      store.append(img[0].split("_")[-4], facet_info, format='table', data_columns=True, complib=str('blosc'), complevel=8)

      # pixel-facet link
      #store.append('s_'+img[0].split("_")[-4], pd.Series(facet_index, index=image_index), format='table', data_columns=True, complib=str('blosc'), complevel=8)

      c.next()
      print(store[img[0].split("_")[-4]].describe())
    
  print(store)
  store.close()

def connect_facet_value(img_list, filename, valuename, **args):
   ''' 
      Store into hdf5. Data structure in Pandas.DataFrame.
   '''
   import pandas as pd
   from numpy import int32, float32, mean, median, radians, array

   store = pd.HDFStore(path.join(prod,valuename+'_'+obj+'_'+fi+'.h5'))
   pd.set_option('io.hdf.default_format','table')

   c = collect(1)
   for img in img_list:

      print(img)

      ret = Retrieve(img, filename, channel=args['channel'])
      facets = ret.all_facets( **args )
      
      # Facet index
      aindex = array(facets.keys()).astype(int32)          
      #aindex = aindex.astype(int32, copy=False)
      
      print('number of active facets: ', aindex.shape[0])
      
      npixels = array( map(lambda x: len(x[8::3]), facets.itervalues()) )
      
      # IF per facet: 
      #rf = sum(rk * solid_angle) / sum(solid_angle)         
      value = pd.Series( map( lambda x: IF_facet(x), facets.itervalues()), index = aindex )
      
      del facets

      # Build Data Frame
      facet_info = pd.DataFrame({valuename : value.astype(float32),
                                 "npix"    : npixels.astype(int32),
                                 }, index=aindex)

      store.append(img.split("_")[-4], facet_info, format='table', data_columns=True, complib=str('blosc'), complevel=8)
      
      c.next()
      print(img.split("_")[-4])
      print(store[img.split("_")[-4]].describe())
    
   print(store)
   store.close()


def list_of_regions(image, zipfile, region_filename, shape='circle', **args):
  ''' 
     From a ds9 .reg list, retrieve the correspoding facets.
  '''
  from numpy import genfromtxt, loadtxt
  import re

  region_list = loadtxt(region_filename, dtype=str, skiprows=3, delimiter=shape, comments='#')


  if len(region_list) == 1: 
    region_list = [list(region_list),]
    
  # Loop over the selected regions
  n = 0
  for reg in region_list:
    n += 1
    reg = map(float, re.split(r'[,)(]+', reg[1])[1:-1])

    p1 = (reg[0]-0.5*reg[2], reg[1]+0.5*reg[3])
    p2 = (reg[0]+0.5*reg[2], reg[1]-0.5*reg[3])

    print('p1: ',p1)
    print('p2: ',p2)

    #try:
    #  mkdir(path.join(prod, region_filename+'_'+str(n)))
    #except OSError:
    #  print('OK.')

    #facets_region.append([])

    #ret.folder = folder
    #ret.prod = path.join(prod, region_filename+str(n))
    retrieve = Retrieve(image, zipfile)      
      
    facets_region = retrieve.region(p1,p2, display=False) 
      
    print('Number of facets contained under this region: \n', len(facets_region))
    
    if label:
      yield {region_label[n-1][:-1]: facets_region}
    else:
      yield facets_region


# END
