# -*- coding: utf-8 -*-
#!/usr/bin/python

# Escrevendo em python3 e usando python2.6:
from __future__ import print_function, unicode_literals, absolute_import, division

__version__="1.0.0"

__doc__='''
  ############################ HAPKE PLOTTING TOOL ################################
  ### Author: Pedro Henrique A. Hasselmann
  ### Last Modified: March, 2016
  ###
  ### Tool for plotting the output solutions from the hapke photometric analysis
  ###
  #################################################################################
'''


######################## GLOBAL IMPORT ##########################################

import glob
from os import path
import pandas as pd
import warnings
warnings.filterwarnings("ignore")
warnings.simplefilter(action = "ignore")

##################################################################################

# Load File path
from ..specs import path_file
home = path.expanduser('~')
obj    = path_file["obj"]
folder = path_file["folder"]
core   = path_file["core"]
aux    = path_file["aux"]    
prod   = path_file["prod"]
fi     = path_file["filter"]

####################################################################################
############################### GRAPHICAL PLOTS ####################################
####################################################################################

from ..output.plot import Plot

class HapkePlot(Plot):

    __doc__ = ''' Python Class dealing with plot display. 
                  Matplotlib interface.
                  Hapke modeling-oriented. 
              '''
    from ..hapke.hapke_model import S, K, Bsh, hpk2012, hpk2008, porosity, p_hg1, p_hg2, hpk_phase_func
    global S, K, Bsh, hpk2012, hpk2008, porosity, p_hg1, p_hg2, hpk_phase_func


    def load_pars(self, hapke_params, p):

      from numpy import float32, fabs, array, radians, sqrt, degrees, cos, ravel, arange, argmin

      self.pars = hapke_params
      
      if p == 'hg1': self.p = p_hg1
      elif p == 'hg2': self.p = p_hg2

    
    def load_geom(self, data):
    
           from numpy import cos
    
           # Shadowing Function
           S_array = S(data['inc'],
                       data['emi'],
                       data['phi'],
                       self.pars['w'],
                       self.pars['theta'])
  
           # Hapke model
           self.model =   S_array*hpk2012(g  = data['phase'],
                          m0 = data['inc'].apply(cos),
                          m1 = data['emi'].apply(cos),
                          p  = self.p,
                          **self.pars)


    def load_hapke_phase_func(self, g):
      return hpk_phase_func(g, **self.pars)


    def single_scattering_curve(self, n, phase_max, step, norm_at=None):

      from numpy import float32, fabs, array, radians, sqrt, degrees, cos, ravel, arange, argmin
      
      par = self.pars
      
      g = arange(0.0, g_max, step)
      F1 = 0.25*0.5*par['K']*par['w']*self.p(g, par['b'])
      self.singlesca_curve = (1e0 + par['Bs0']*Bsh(g, par['hs']))*F1

      frame = self.frame[n]

      frame.plot(degrees(g), norm_hapke  * self.singlesca_curve, 'k-', linewidth=args["s"])
      #frame.scatter(phase_bin, ravel(model)-0.005, s=args["s"], color='red')
      frame.set_ylabel('Radiance factor Normalized', fontsize=12)

      frame.minorticks_on()
      frame.tick_params('both', length=7, width=1.6, which='major')
      frame.tick_params('both', length=3, width=0.7, which='minor')


    def compare(self, n, data, 
                      mincount=1, 
                      gridsize=200, 
                      alpha=0.4, 
                      markersize=30e0, 
                      cmap='gray', 
                      colorbar_title='N [facets]', 
                      **args):
       '''
          Compare Hapke.model to data.
          Over-plot scattering curves and show residue chi2.
       '''
       from numpy import float32, degrees, sqrt, nanmedian, nanmean, nanstd, isnan
       frame = self.frame[n]
       par   = self.pars

       # Data
       phasecurve, phasebin = self.scatteringcurve(0, data, y='IF', cmap=cmap, 
                                                   gridsize=gridsize, mincount=mincount, 
                                                   alpha=alpha, 
                                                   colorbar_title=colorbar_title,
                                                   **args)
       # Hapke model         +0.08
       frame.scatter(phasebin, self.model.dropna(how='all').values.flatten(), s=markersize, color='red', alpha=0.08) #0.008 #0.15

       res = (((data['IF'] - self.model)/sqrt(self.model))**2).dropna(how='all').values.flatten()
       phase = phasebin[~isnan(res)]
       
       
       print('Chi^2: ', res[~isnan(res)].mean())

       #frame.scatter(phase, -0.015 + res[~isnan(res)])
       frame.hexbin(phase, -0.015 + res[~isnan(res)], cmap=cmap,
                    gridsize=400, mincnt=mincount, alpha=alpha,extent=(0.0,70.0,-0.02,0.0))
       
       from numpy.polynomial.polynomial import polyfit, polyval
       line = polyfit(phase, -0.015 + res[~isnan(res)], deg=1, full=False)
       print('line: ',line)
       frame.plot([phase.min(), phase.max()], polyval([phase.min(), phase.max()],line), 
                  linestyle='--', color='black', linewidth=1.5, dashes=(50,10))
       
       return phasecurve, phasebin

# END





def plot_correlation(par1, par2, filename):
  '''
   # from the file containing the best solutions, check the correlation among the parameters.
  '''

  from numpy import load, float32
   
  solutions = load(path.join(prod, filename+'.npz'))
  N_tests = range(len(solutions['solutions']))
  
  tests = pd.DataFrame(solutions['solutions'], 
                       index=N_tests, 
                       columns=('w','gsca','Bs0','hs','Bc0','hc','theta'),
                       dtype=float32)
  tests['RMS'] = solutions['RMS']
  
  # best solution
  best_sol = tests['RMS'].argmin()
  print('best solution: \n', tests.loc[best_sol])
  
  # par1 vs par2
  fig = plt.figure(1, figsize = (10,10), dpi=120)
  f = fig.add_subplot(111)
  
  f.plot(tests[par1].values, tests[par2].values, 'k.') # All points
  f.plot(tests.loc[best_sol, par1], tests.loc[best_sol, par2], 'r*') # Best solution
  f.set_ylabel(par2, fontsize=18)
  f.set_xlabel(par1, fontsize=18)

  f.minorticks_on()
  f.tick_params('both', length=9, width=2, which='major')
  f.tick_params('both', length=4, width=1, which='minor')

  plt.show()
  plt.clf()


def single_scattering_function(data, plotname, *params, **args):
  '''
    Compare phase function of remote sensing and
    the radio-goniometer data.
    
    params --> [P_hg, w, b, c, Bsh, hs]
    
  '''
  
  import matplotlib.cm as cm
  from ..hapke.hapke_model import hpk2012, p_hg1, p_hg2, Bsh, Bcb, K
  from numpy import arange, linspace, degrees, ravel
  from ..output.output import tableau20, tableau

  f, frame = plt.subplots(1, sharex=True)
 
  g = arange(0.0, 1.0, 0.001)
  phase_bin = ravel(data["phase"].apply(degrees).values)
   
  phasecurve =  frame.hexbin(phase_bin, ravel(data['IF'].values),
                   gridsize=100, mincnt=20, alpha=0.6, cmap=cm.Greys)

  tab = tableau(0)  
  print(params)
  for par in params:
    
    k = K(par[5])
    #F = hpk2012(K, g, 0.0, 0.0, p, w, b, Bs0, hs, Bc0, hc, c)
    F1 = 0.25*0.5*k*par[1]*par[0](g, par[2], par[3])
    F2 = (1e0 + par[4]*Bsh(g, par[5]))*F1
    #F3 = (1e0 + par[4]*Bsh(g, par[5]))*(1e0 + par[6]*Bcb(g, k, par[7]))*F1
    c = tab.next()
    #frame.plot(degrees(g), F, '-', color=c, label=str(par), **args)
    frame.plot(degrees(g), F1, '-', color=c, label='gsca='+str(par[2])+', p_hg1(gsca)', **args)
    frame.plot(degrees(g), F2, '--', color=c, label='gsca='+str(par[2])+', (1 + B0*Bsh(hs))*p_hg1(gsca)', **args)
    #frame.plot(degrees(g), F3, '-.', color=c, label=str(par[2])+', (1 + Bsh(hs))*p_hg1(gsca)', **args)
    c = tab.next()

  frame.minorticks_on()
  frame.tick_params('both', length=9, width=2, which='major')
  frame.tick_params('both', length=4, width=1, which='minor')
  frame.set_xlabel('Phase angle [deg]', fontsize=14)
  frame.set_ylabel('Radiance factor', fontsize=14)
  
  frame.set_xlim(None,degrees(1.0))
  frame.legend(loc=0, fontsize=12, frameon=False)
  plt.draw()
  plt.savefig(path.join(prod,plotname), dpi=300, bbox_inches='tight')
  plt.show()
  plt.clf() 


def plot_ordered_solution(files):
  '''
    Plot hapke test parameters sorted by descending RMS: It shows how the solution converge to a common solution.
  
     input:
     files --> list
  '''

  from numpy import load, float32, int8, exp, log, array, cumsum, histogram
  from scipy.optimize import curve_fit
  from math import sqrt

  # Load more several runs into one single Pandas.dataframe
  solutions = {'solutions': list(), 'RMS': list()}
  
  for filename in files:
    print(filename)
    solutions['solutions'].extend( load(path.join(prod, filename+'.npz'))['solutions']  )
    solutions['RMS'].extend( load(path.join(prod, filename+'.npz'))['residues'] )
    
  N_tests = array(range(len(solutions['solutions'])), dtype=int8)

  tests = pd.DataFrame( array(solutions['solutions']), 
                       index=N_tests, 
                       columns=('w','b','Bs0','hs','Bc0','hc','c','theta'),
                       dtype=float32)
  
  tests['RMS'] = array( solutions['RMS'] )

  # Descendent RMS sort
  RMS_sorted = tests.sort(['RMS'], ascending=False)
  RMS_index = map(str, RMS_sorted.index.values)
  
  for par in tests.columns:
    print(par)
    fig = plt.figure(1, figsize = (12,6), dpi=120)
    
    #print(log(RMS_sorted['RMS'].iloc[0]/RMS_sorted['RMS']))
    
    # Ordered by RMS
    f1 = fig.add_subplot(111) 
    f1.plot(N_tests, RMS_sorted[par], 'k.', linewidth=3.0, linestyle='-', drawstyle='steps')
    f1.set_ylabel('$'+par+'$', fontsize=18)
    f1.set_xlabel('Test', fontsize=18)
    plt.xticks(N_tests, RMS_index, size='small')
   
    ax2 = f1.twiny()
    ax2.set_xlabel("$RMS$", fontsize=18)
    ax2.set_xticks(N_tests)
    ax2.set_xticklabels(map(str, RMS_sorted['RMS']), rotation=90)
    ax2.tick_params(axis='x', labelsize='small')
    
    # Cumulative distribution
    '''f2 = fig.add_subplot(212)   
    f2.hist(RMS_sorted[par], bins=int(2*sqrt(len(solutions['solutions']))),
            weights= log(RMS_sorted['RMS'].ix[0]/RMS_sorted['RMS']),
            normed=True,
            color='k', linewidth=3.0, linestyle='-', histtype='step')
    f2.set_ylabel('f', fontsize=18)
    f2.set_xlabel('$'+par+'$', fontsize=18)
    
    f2.minorticks_on()
    f2.tick_params('both', length=9, width=2, which='major')
    f2.tick_params('both', length=4, width=1, which='minor')'''  
   
    plt.show()
    plt.clf()
    plt.close()

# Check for correlations among the hapke parameters in the produced fits maps
def hapke_correlation(map1, map2, label1, label2, x, y):

  import matplotlib.ticker as plticker
  from numpy import ravel, arange, array, zeros
  from scipy.stats import spearmanr
  import pandas as pd
  
  par1 = fits.open(map1+'.fit')[0].data[x[0]:x[1],y[0]:y[1]]
  par2 = fits.open(map2+'.fit')[0].data[x[0]:x[1],y[0]:y[1]]
  format = par1.shape

  #plt.imshow(par1)
  #plt.show()
  #plt.clf()
  
  #pixels = pd.Series(zeros(format[0]*format[1]), index=arange(format[0]*format[1]))

  # remove zero pixels and flatten
  par1 = ravel(par1)
  par2 = ravel(par2)

  r = spearmanr(par1, par2)

  # Plot
  fig = plt.figure(1, figsize = (10,10), dpi=100)
  frame = fig.add_subplot(111)
  
  print(label1, par1[par1>0].mean(), par1[par1>0].std())
  mx = par1[par1>0].mean()
  sx = par1[par1>0].std()
  print(label2, par2[par1>0].mean(), par2[par1>0].std())
  my = par2[par1>0].mean()
  sy = par2[par1>0].std()
  
  hexbin = plt.hexbin(par1[par1>0], par2[par1>0], gridsize=250, 
                      extent=(mx-2*sx,mx+2*sx,my-2*sy,my+2*sy), mincnt=10)
                      
  cbar = plt.colorbar(pad=0.02)
  cbar.ax.set_ylabel('Number of pixels', 
  fontsize=20, 
  rotation=270, 
  labelpad=26.0)
  
  plt.title("spearman: "+str(r[0]))
  plt.xlabel(label1, fontsize=20)
  plt.ylabel(label2, fontsize=20)
  
  frame.tick_params(which='major',axis='both',
                    color='k',length=5,width=2.5)  
  
  plt.show()
  plt.clf()

def size_spatial_distribution(filename, hs_image, K_image):

  from astropy.io import fits

  hs = fits.open(hs_image+'.fit')[0].data
  K = fits.open(K_image+'.fit')[0].data
  
  Ea = 2e0*hs/K
  
  # Empty initial HDU
  initial = fits.PrimaryHDU()
  output = fits.HDUList([initial])
  Ea = fits.PrimaryHDU(Ea)
  output.append(Ea)
  output.writeto(filename, output_verify='warn')
