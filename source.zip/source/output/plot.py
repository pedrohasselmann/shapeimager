# -*- coding: utf-8 -*-
#!/usr/bin/python

# Escrevendo em python3 e usando python2.6:
from __future__ import print_function, unicode_literals, absolute_import, division

__version__="1.0.0"

__doc__='''
  ############################ MAIN PLOT TOOL ################################
  ### Author: Pedro Henrique A. Hasselmann
  ### Last Modified: March, 2016
  ###
  ### Tool for graphical plotting using matplotlib.
  ###
  ###
  ### Class: Plot
  ###
  ### Attributes:
  ###          
  ###  
  ###   
  ###     
  ###             
  ###
  #############################################################################
'''
####################################################################################
from os import path
import glob
import pandas as pd
from itertools import cycle
from numpy import array, degrees, radians, ravel, linspace

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.cm import Paired

##########################################################################################

#http://www.randalolson.com/wp-content/uploads/percent-bachelors-degrees-women-usa.png
tableau20 = [(31, 119, 180), (174, 199, 232), (255, 127, 14), (255, 187, 120),    
             (44, 160, 44), (152, 223, 138), (214, 39, 40), (255, 152, 150),    
             (148, 103, 189), (197, 176, 213), (140, 86, 75), (196, 156, 148),    
             (227, 119, 194), (247, 182, 210), (127, 127, 127), (199, 199, 199),    
             (188, 189, 34), (219, 219, 141), (23, 190, 207), (158, 218, 229)]    
  
# Scale the RGB values to the [0, 1] range, which is the format matplotlib accepts.    
def tableau(start):
  for i in tableau20[start:]:    
    r, g, b = i    
    yield (r / 255., g / 255., b / 255.)

color_cycle = cycle(('#FE2E2E','#B40404','#08088A','#2E9AFE','green','#FF8000','#086A87','purple','#8A0829','magenta','#FF0040','#0B3B0B','black'))
color_space = lambda x: cycle(Paired(linspace(0, 1, x)))
symbols = cycle(('^','o','d','s','*','p','8','+','1','x'))
linestl = cycle(('solid', 'dashed', 'dashdot', 'dotted'))


##############################################################
################### GRAPHIC PLOTS ############################
##############################################################
font = {'family' : 'serif',
        'weight' : 'bold',
        'size'   : 20}
class Plot:
  __doc__ = ''' Python Class dealing with plot display. 
                Matplotlib interface. 
            '''
  import matplotlib
  matplotlib.rc('font', **font)
  #matplotlib.rc('text', usetex=True)
  matplotlib.rcParams['agg.path.chunksize'] = 1000

  def __init__(self, ncols=1, nlines=1, size=(10,8), title=['',], fcolor='k', background='white', shared_axis=False):

     self.fig, frame = plt.subplots(ncols, nlines, figsize=size, sharey=shared_axis, sharex=False, subplot_kw={'adjustable':'box-forced'})
     self.fcolor =fcolor
     self.background = background
     self.title = title
     
     if ncols == 1 and nlines == 1: 
             self.frame = [frame, ]
     else:
             self.frame = frame.flatten()
         
     for n, fr in enumerate(self.frame):
       fr.set_facecolor(background)
       fr.set_alpha(0.8)
       fr.minorticks_on()
       fr.tick_params('both', length=9, width=1.8, which='major', direction='inout', color=fcolor, top=True, right=True)
       fr.tick_params('both', length=4, width=0.9, which='minor', direction='inout', color=fcolor, top=True, right=True)

       fr.set_title(title[n], fontweight='bold', fontsize=int(1.0*font['size']))

     plt.xticks(fontsize = font['size'])
     plt.yticks(fontsize = font['size'])

  def show(self, tight=False):    
     plt.legend(loc=0, fontsize=font['size']-7, numpoints=1, frameon=False)
     if tight: plt.tight_layout()
     plt.draw()
     plt.show()
     plt.clf()

  def close(self):
    plt.cla()
    plt.clf()
    plt.close()

  def save(self, pathname, dpi=300, tight=False, **args):    
     plt.legend(loc=0, fontsize=28, numpoints=1, frameon=False)
     if tight: plt.tight_layout()
     plt.savefig(pathname, dpi=dpi, bbox_inches='tight', **args)

  def ylim(self,minimum,maximum):
     for fr in self.frame:
        fr.set_ylim(minimum, maximum)
        fr.set_ybound(minimum, maximum)

  def xlim(self,minimum,maximum):
     for fr in self.frame:
        fr.set_xlim(minimum, maximum)
        fr.set_xbound(minimum, maximum)

  def xlabel(self,n,x,fontsize=35):
     self.frame[n].set_xlabel(x, fontsize=fontsize, fontweight='bold')

  def ylabel(self,n,y,fontsize=35):
     self.frame[n].set_ylabel(y, fontsize=fontsize, fontweight='bold')

  def label_axes(self,x,y,fontsize=35):
     for fr in self.frame:
        fr.set_xlabel(x, fontsize=fontsize, fontweight='bold')
        fr.set_ylabel(y, fontsize=fontsize, fontweight='bold')

  def colorbar(self, data, title, ticks=15, **args):
     # Color Bar

     cbar = self.fig.colorbar(data, orientation='vertical', pad=.02, aspect=30, fraction=0.04)
     if title != None: cbar.ax.set_ylabel(title, fontsize=32, fontweight=font['weight'], labelpad=25.0)

     tick_locator = ticker.MaxNLocator(nbins=ticks)
     cbar.locator = tick_locator
     cbar.ax.tick_params(labelsize=int(0.9*font['size']))
     cbar.update_ticks()
     
  def text(self, n, write, pos, **args):
              self.frame[n].text(
                        pos[0],
                        pos[1], 
                        write, 
                        color=self.fcolor, 
                        fontsize=args['fontsize'],
                        fontweight='bold',
                        horizontalalignment=args['horiz_align'],
                        verticalalignment=args['vertical_align']
                        #bbox=dict(facecolor='white', edgecolor='white', alpha=0.7)
                        )


  # Continuous and filled errorbar
  def errorfill(self, n, x, y, yerr, 
                                    alpha_fill=0.3, 
                                    ax=None, 
                                    **args):
  
    from numpy import isscalar
   
    ax = ax if ax is not None else plt.gca()

    
    if isscalar(yerr) or len(yerr) == len(y):
        ymin = y - 0.5*yerr
        ymax = y + 0.5*yerr
        
    elif len(yerr) == 2:
        ymin, ymax = yerr
        ymin = y + ymin
        ymax = y + ymax

    if not args.has_key('marker'): args['marker'] = next(symbols)    
    if not args.has_key('color'): args['color'] = next(color_cycle)

    ax.plot(x, y, **args)
    ax.fill_between(x, ymax, ymin, color=args['color'], alpha=alpha_fill)
    
    return ax


  def curve(self, n, x, y, **args):
    
    if not args.has_key('marker'): args['marker'] = next(symbols)
    for n, fr in enumerate(self.frame): fr.plot(x, y, **args)


  def scatteringcurve(self, n, data,
                            x = 'phase',
                            y = 'IF', 
                            mincount=1, 
                            gridsize=100, 
                            disk=1.0,
                            colorbar_title='N',
                            **args):

     from numpy import fabs, amax, amin
     
     phasebin = data[x].dropna(how='all').apply(degrees).values.flatten()

     phasecurve = self.frame[n].hexbin(phasebin, (data[y]/disk).dropna(how='all').values.flatten(),
                   gridsize=gridsize, mincnt=mincount, **args)

     cbar = self.colorbar(phasecurve, colorbar_title, ticks=8)
     
     return phasecurve, phasebin


  def distribution(self, n, data,
                   samples = (10000,100),
                   alpha = 0.05,
                   **args):
     
     from numpy import nanmedian, nanstd, histogram, subtract, nanpercentile, nanmax, nanmin, isnan
     from scipy.stats import skew
     from ..support.statistics import bootstrap

     # clean data
     data = data[~isnan(data)]
     
     if 'bins' not in args.keys():
       IQR = subtract(*nanpercentile(data, [75, 25])) # interquartile range

       h = 2e0 * IQR * data.shape[0]**(-1e0/3)
       
       arg['bins'] = int((nanmax(data) - nanmin(data))/h)
     
     # the histogram of the data
     #hist, bin_edges = histogram(data, **args)
     self.frame[n].hist(data, **args)
     
     # statistics
     ct =  nanmedian(data) #bootstrap(data, num_samples, nanmedian, alpha)
     #dev_up = bootstrap(data, num_samples, lambda x, a: nanpercentile(x, axis=a, q=50+34.1+13.6), alpha)
     #dev_low = bootstrap(data, num_samples, lambda x, a: nanpercentile(x, axis=a, q=50-34.1-13.6), alpha)
     dev2 = nanpercentile(data, q=[50+34.1+13.6, 50-34.1-13.6])
     sk = bootstrap(data, samples, skew, alpha)
     
     print('Central tendency (median): ', ct)
     #print(dev_up, dev_low)
     print('IQR deviation (2-sigma): ', dev2)
     print('Skewness:', sk)
     
     self.frame[n].axvline(ct, color='red', linestyle='dashed', linewidth=2, label='Median')       # Central tendency
     #self.frame[n].axvline(ct[1], color='red', linestyle='dashed', linewidth=2)   # upper Central tendency     
     self.frame[n].axvline(dev2[1], color='green', linestyle='dashed', linewidth=4,label='$IQR_{2\sigma}$') # Lower 2x average deviation
     self.frame[n].axvline(dev2[0], color='green', linestyle='dashed', linewidth=4) # upper 2x average deviation
     self.frame[n].legend(loc=0,frameon=False)
     
     return ct, dev2, sk



  def distribution2D(self, n, data, Z=None,
                            mincount=1, 
                            gridsize=20, 
                            title='density',
                            ticks=8,
                            **args):

     density =  self.frame[n].hexbin(data[:,0], data[:,1], C=Z,
                   gridsize=gridsize, mincnt=mincount, **args)

     cbar = self.colorbar(density, title, ticks)
     


  def ellipse(self, n, cov, ct, pos, **kwargs):
   """
    Plots an `nstd` sigma error ellipse based on the specified covariance
    matrix (`cov`). Additional keyword arguments are passed on to the 
    ellipse patch artist.

    Parameters
    ----------
        cov : The 2x2 covariance matrix to base the ellipse on
        ct  : The location of the center of the ellipse. Expects a 2-element
            sequence of [x0, y0].
        nstd : The radius of the ellipse in numbers of standard deviations.
            Defaults to 2 standard deviations.
        ax : The axis that the ellipse will be plotted on. Defaults to the 
            current axis.
        Additional keyword arguments are pass on to the ellipse patch.

    Returns
    -------
        A matplotlib ellipse artist
   """
   from numpy.linalg import eigh, norm
   from numpy.linalg.linalg import LinAlgError
   from numpy import array, degrees, sqrt, arctan2, fabs, sum, argmax, outer, dot
   from matplotlib.patches import Arc

   def eigh_proj(cov, pos):
      cov_proj = array([
                       [cov[pos[0],pos[0]], cov[pos[0],pos[1]]
                        ],
                       [cov[pos[1],pos[0]], cov[pos[1],pos[1]]
                        ]])
      vals, vecs = eigh(cov_proj)
      vecs = array(vecs)#[pos,:]
      mag_proj  =  sqrt(fabs(vals)) * sqrt( sum(vecs*vecs, 0) )
      #order = mag_proj.argsort()[::-1]
      order = vals.argsort()[::-1]
      return vals[order], vecs[:,order], mag_proj[order]


   vals, vecs, mag = eigh_proj(cov, pos)
   axis = sqrt(fabs(vals))

   theta = degrees(
                     arctan2(*vecs[:,0][::-1])
                     )

   # Normal Vector to Principal eigenvector
   norm_majoraxis = axis[0] * array([ - vecs[1,0], vecs[0,0] ]) / mag[0]
   # The projection of all secondary eigenvectors to the main eigenvector.
   large_proj_vec =  max( axis * fabs( sum(vecs.T * norm_majoraxis, 1) )  )
   width = 2  * mag[0]
   height = 2 * large_proj_vec
   
   for q1 in [1,2,3]:
     ellip = Arc(
                 xy     = ct[[pos[0],pos[1]]], 
                 width  = q1*width, 
                 height = q1*height, 
                 angle  = theta,
                 linestyle='solid', 
                 linewidth=2.0, 
                 **kwargs
                 )

     self.frame[n].add_artist( ellip )


  def parametric_variation_curves(self, n, params, cov, angle, func, N=30, **args):
     ''' 
        Plot locus of parametric uncertainties 
     '''
     from numpy.random import multivariate_normal
  
     p_dist = multivariate_normal(params, cov, N) # random values

     for p in list(p_dist):
        self.curve(n, degrees(angle), func(angle, *p),
                                          color = self.frame[n].get_lines()[-1].get_color(),
                                          marker = self.frame[n].get_lines()[-1].get_marker(),
                                          **args)


  def measured_vs_modeled(self, n,
                          meas, 
                          model,
                          weight=None,
                          gridsize=100,
                          mincount=1,
                          **args):
     '''
       Measured radiometric data (meas) vs modeled data (model).
     '''
     from numpy import float32, isnan, median
     from numpy.polynomial.polynomial import polyfit, polyval

     meas = meas[~isnan(model)]
  
     # versus plot
     versus = self.frame[n].hexbin(meas, model[~isnan(model)], gridsize=gridsize, mincnt=mincount, **args)
  
     # Fit line
     coefs = polyfit(model[~isnan(model)][(meas>0.005) & (meas<0.08)], meas[(meas>0.005) & (meas<0.08)], 1, full=False)
     y = polyval(meas, coefs)
     print(coefs)
   
     fit = self.frame[n].plot(meas, y, color='red', linewidth=4.0, label=str(round(100 - 100*coefs[1],2))+'\%')
  
     # Straight Line
     self.frame[n].plot([meas.min(), meas.max()], [meas.min(), meas.max()], linewidth=4.0, color='black')

     self.colorbar(versus, 'Number of cells', nbins=10)    

  def compare_sequences(self, n, 
                        data, # pandas.DataFrame of TEST: {dates: values}
                        **args):
     '''
        Compare values calculated from different tests with respect to several dates.
     '''
     import matplotlib.ticker as ticker
     from pandas import Series

     #data = pd.HDFStore(path.join(folder, hdf+".h5"))
     #phase = dict([(img[16:-21],degrees(data[img]['phase'].mean(0))) for img in data.keys()])
     #data.close()

     fr1 = self.frame[0]
     #fr2 = fr1.twiny()
  
     '''for f in glob.glob(path.join(prod, search+".h5")):
       hdf = pd.HDFStore(f)
       print(str(f[-20:-3]))
       print(hdf[r])
       dates = map(lambda x: x[15:-21], hdf[r].index)
       pha = map(lambda x: round(phase[x[15:-21]],2), hdf[r].index)
       fr1.plot(range(len(dates)), 100*hdf[r].values, 's-', markersize=6.0, linewidth=3.0, label=str(f).split('_')[1])
       hdf.close()'''

     for test in data.keys():
       dates = data[test].keys() 
       fr1.plot(range(len(dates)), data[test].values(), 's-', markersize=6.0, linewidth=3.0, label=test)

     plt.xticks(fontsize = font['size']-5)
     plt.yticks(fontsize = font['size']-5) 
     fr1.set_xticks(range(len(dates)))
     fr1.set_xticklabels(dates, rotation=45, ha='right')
     #fr2.set_xticks(range(len(dates)))
     #fr2.set_xticklabels(pha, rotation=90)

     #loc = ticker.MultipleLocator(base=50.0) # this locator puts ticks at regular intervals
     #fr1.xaxis.set_major_locator(loc)
     #fr1.yaxis.set_major_locator(loc)






  def plot_residue_filters(self, phasefunc, search="gfit_*",upper=0.5, **args):
  
     from numpy import  sqrt
     from itertools import cycle

     fig = self.fig
     line= cycle(['-','--',':','-.'])
     symbol= cycle(('s', 'o', '*'))
  
     for f in glob.glob(path.join(prod, search+".h5")):
        hdf = HDFStore(f)
        print(f[-11:-3])
        pha = hdf["global_albedo"]['phase'].values
        akimov_albedo = phasefunc(pha, *hdf["average_phase_params"].values)
        res = sqrt((hdf["global_albedo"]['Aeq'] - akimov_albedo)**2)/hdf["global_albedo"]["Aeq"]
        plt.plot(degrees(pha), 100*res.values, symbol.next(), markersize=8.0, linewidth=2.0, linestyle=line.next(), label=str(f[-10:-3]))
        hdf.close()
  
     plt.plot((20,20), (0,10), 'k-',linewidth=2.0)
     plt.plot((5,5), (0,10), 'k-',linewidth=2.0)
  
     plt.xlabel("Phase Angle", fontsize=22)  
     plt.ylabel('Residue (%)', fontsize=22)

     plt.legend(loc=0, numpoints=1, fontsize=15)


  def plot_disk_coef(self, hdf, search="ifit_*", **args):
  

     import matplotlib.ticker as plticker
     from numpy import  all
     import numpy.polynomial.polynomial as poly
  
     polyfit = poly.polyfit
     polyval = poly.polyval

     data = pd.HDFStore(path.join(folder, hdf+".h5"))
     phase = dict([(img[16:-21],degrees(data[img]['phase'].mean(0))) for img in data.keys()])
     print(phase)
     data.close()
  
     fig = self.fig
     fr1 = self.frame[0]
  
     for f in glob.glob(path.join(prod, search+".h5")):
       hdf = pd.HDFStore(f)
       
       if not all(hdf['disk_coefs'].values == 0.0):

         print(str(f[-29:-3]))
         print(hdf['disk_coefs'])
         #dates = map(lambda x: x[15:-21], hdf[r].index)
         pha = map(lambda x: round(phase[x[15:-21]],2), hdf['disk_coefs'].index)
         fr1.plot(pha, hdf['disk_coefs'].values, 's', markersize=8.0, label=str(f).split('_')[1])
         disk_params = list(polyfit(pha, hdf['disk_coefs'].values,1))
         fr1.plot(pha, polyval(pha, disk_params, tensor=False), '--')
       hdf.close()  

     fr1.legend(loc=0, numpoints=1, fontsize=20)
  
     fr1.set_xlabel("Phase Angle", fontsize=22, family='monospace')
     fr1.set_ylabel('Disk Coefficient', fontsize=22, family='monospace')

     fr1.set_ylim(0.0,1.0)


  def plot_emi_vs_inc(self, data, gridsize=40, mincnt=1, alpha=0.9, **args):
   '''
     Plot emergence angle vs incidence angle 
     with temperature scale corresponding to I/F value.
   '''
  
   IF = data['IF']
   data = data.apply(degrees)  
  
   p1 = self.frame[0].hexbin(ravel(data['emi'].values), 
                   ravel(data['inc'].values),
                   C=ravel(IF.values), 
                   gridsize=gridsize, mincnt=mincount, alpha=alpha)

   self.frame[0].minorticks_on()
   self.frame[0].tick_params('both', length=7, width=1.6, which='major')
   self.frame[0].tick_params('both', length=3, width=0.7, which='minor')
  
   plt.xlabel('Emergence Angle (deg.)', fontsize=15)
   plt.ylabel('Incidence Angle (deg.)', fontsize=15)                        
   cbar = plt.colorbar( orientation='vertical', pad=.02, aspect=30)
   cbar.ax.set_ylabel('I/F', fontsize=15)

  def spectral_slope_img(self, image_filter, image_scale):

     from spectra import spectral_slope
   
     slope = spectral_slope(image_filter)

     fig, frame = self.fig, self.frame
  
     imgplot = plt.imshow(100*slope[::-1,:])
     imgplot.set_clim(1,5)  # Colorbar limits
     imgplot.set_cmap(cmap='spectral')
  
     # scale bar
     plt.errorbar(300,820, 
     xerr=2/image_scale, 
     markersize=0.001, 
     linewidth=10.0,
     color='k')
  
     plt.text(300,800,'2 km', 
     color='k', 
     verticalalignment='center', 
     horizontalalignment='center',
     fontweight='bold',
     fontsize=26)
  
     # Colorbar
     cbar = plt.colorbar(fraction=0.046, pad=0.04)
     cbar.ax.set_ylabel('spectral slope (%/microns)',
     fontsize=30, 
     rotation=270, 
     labelpad=32.0)
   
     # Ticks
     loc = plticker.MultipleLocator(base=100.0) # this locator puts ticks at regular intervals
     frame.xaxis.set_major_locator(loc)
     frame.yaxis.set_major_locator(loc)
     frame.tick_params(which='major',axis='both',
                    color='k',length=10,width=3,
                    )  





# END
