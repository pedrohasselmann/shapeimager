
# Paths
# Edit it wherever you wish!

__doc__='''
##############################################################################################
# Author: Pedro H. Hasselmann, Rio de Janeiro, Brazil (LESIA-OBSPM/ON-MCTI)
#
#  Path Files:
#
# "obj"    : Object name or label.
# "folder" : Directory of calibrated and aligned images.
# "core"   : Directory of GASKELL geo images | OASIS rendered images and s_ and g_ files.
# "aux"    : Directory of auxiliary .dat or .txt files and also .obj Shape Model.
# "kern"   : Directorty of NAIF/SPICE Kernels
# "prod"   : Directory where products and secondary data structures are stored.
# "filter" : filter name.
##############################################################################################
'''

path_file = {
"obj"    : 'OREX_BENNU_DL06',
"core"   : 'OREX/Imager/pkl/',
"folder" : 'OREX/Imager/',
"aux"    : 'OREX/SHAPE_MODEL/Sample_Sites_DTM/',
"prod"   : 'OREX/Imager/',
"kern"   : 'OREX/KERNELS/spoc/',
"filter" : "OLAv13_map_l2iof_x"
}
'''
path_file = {
"obj"    : '67P_ABYDOS',
"core"   : 'ROSETTA/ABYDOS/',
"folder" : 'ROSETTA/ABYDOS/list_Abydos_images_mixed_shapemodels/1deg/',
"aux"    : 'ROSETTA/SHAPE_MODEL/',
"prod"   : 'ROSETTA/ABYDOS/',
"kern"   : 'ROSETTA/KERNELS/',
"filter" : "NAC_F22"
}
'''

####################
## Physical Units ##
####################
#import astropy.units as u
au_km = 149597870.659999996424 #u.au.to(u.km)
# Solar Bolometric Irradiance (S0=1.3608+-0.0005  kW/m2)
irradiance = lambda inc,Dsun: 1.3608*cos(inc)/Dsun**2
temperature = lambda irr, e: (0.25*0.17635524153*irr*10e8/e)**(1e0/4)

# Central Wavelength of OSIRIS/ROSETTA filters
central_filter = {
                  'NAC_F15': 269.3,
                  'WAC_F71': 325.8,
                  'NAC_F16': 360.0,
                  'WAC_F13': 375.6,
                  'NAC_F84': 480.7,
                  'NAC_F24': 480.7,
                  'NAC_F83': 535.7,
                  'NAC_F23': 535.7,
                  'WAC_F15': 572.1,
                  'WAC_F16': 590.7,
                  'WAC_F18': 612.6,
                  'WAC_F17': 631.0,
                  'NAC_F82': 649.2,
                  'NAC_F22': 649.2,
                  'NAC_F87': 701.2,
                  'NAC_F27': 701.2,
                  'NAC_F28': 743.7,
                  'NAC_F88': 743.7,
                  'NAC_F51': 805.3,
                  'NAC_F41': 882.1,
                  'NAC_F61': 931.9,
                  'NAC_F71': 989.3,
                 }

abs_coef_error = {
                  'NAC_F15': 0.005,
                  'NAC_F16': 0.005,
                  'WAC_F13': 0.009,
                  'NAC_F84': 0.000,
                  'NAC_F24': 0.001,
                  'NAC_F83': 0.001,
                  'NAC_F23': 0.001,
                  'WAC_F15': 0.001,
                  'WAC_F16': 0.005,
                  'WAC_F18': 0.001,
                  'WAC_F17': 0.001,
                  'NAC_F82': 0.001,
                  'NAC_F22': 0.001,
                  'NAC_F87': 0.001,
                  'NAC_F27': 0.001,
                  'NAC_F88': 0.003,
                  'NAC_F51': 0.007,
                  'NAC_F41': 0.001,
                  'NAC_F61': 0.001,
                  'NAC_F71': 0.007,
                 }

# OSIRIS-REX OCAMS
central_filter_orex = {
                       'MapCam_L2b': 470.0, #FW 0.06
                       'MapCam_L2v': 550.0, #FW 0.05 
                       'MapCam_L2w': 700.0, #FW 0.05
                       'MapCam_L2x': 860.0, #FW 0.08
                       }
