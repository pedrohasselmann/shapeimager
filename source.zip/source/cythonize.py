# -*- coding: utf-8 -*-
#!/usr/bin/python

'''
  Setup.py to externally build a cython code.
  
  python -O cythonize.py build_ext --inplace
'''
from setuptools import setup, find_packages, Extension
#from distutils.core import setup
#from distutils.extension import Extension
from Cython.Build import cythonize
from Cython.Distutils import build_ext
from numpy import get_include
import shutil
from os import path, name, remove, getcwd
print(name)

pyxfiles = [path.join('source','model','multiproc_specs.pyx'),
            path.join('source','model','hapke_model.pyx'),
            path.join('source','model','vanginneken_model.pyx'),
            #path.join('source','geo','oasis','load_oasis.pyx'),
            path.join('source','geo', 'imager_utils.pyx'),
            path.join('source','model', 'diskfunc.pyx'),
            path.join('source','model', 'phasefunc.pyx'),
            path.join('source','model', 'stochastic_from_func.pyx')]

module_names = ["multiproc_specs",
                "hapke_model",
                "vanginneken_model",
                "imager_utils",
                "diskfunc",
                "phasefunc",
                "stochastic_from_func"] #, "load_oasis"

for n, pyx in enumerate(zip(pyxfiles, module_names)):
  pyxfile, module_name = pyx[0], pyx[1]
  #print(pyxfile)
  # Linux
  if name != 'nt':
    tree = pyxfile.split('/')
  if name == 'nt':
    tree = pyxfile.split('\\')
  #raw_input([path.join(getcwd(),'source','model',md) for md in module_names[:n]])
  ext_modules = [Extension('.'.join((tree[0],tree[1],module_name)), 
                           [pyxfile],
                           extra_link_args=["-fopenmp"],
                           include_dirs=['.',path.join(getcwd(),'source','model')],
                           extra_compile_args=["-O3", "-fno-math-errno", "-funsafe-math-optimizations", "-fcx-limited-range", "-fexcess-precision=fast", "-fopenmp","-w"])] #"-ffast-math"

  ext_modules[0].cython_directives = {"embedsignature": True}

  setup(
  name = module_name,
  #cmdclass = {'build_ext': build_ext},
  include_dirs = [get_include()],
  ext_modules = cythonize(ext_modules, build_dir="build", include_path=[path.join(getcwd(),'source','model'),]),
  script_args=['build_ext'],
  options={'build_ext':{'inplace':True}},
  include_package_data=True,
  package_data={'source.model': [path.join(getcwd(),'source','model','*.pxd'),]}
  )

# END
