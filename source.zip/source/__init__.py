# -*- coding: utf-8 -*-
#!/usr/bin/python

__version__="4.0.0"

__doc__='''
#########################################################################################
#  author: Dr. Pedro H. A. Hasselmann, Rio de Janeiro, Brasil (LESIA-OBSPM/ON-MCTI)
#
#  PHOTMODEL
#  =========
#
#  requirements:
#      essential: numpy, scipy, pandas, matplotlib, astropy, cython
#      support:   mayavi, gdal, osgeo
#
#
#  Path Files (source/specs.py):
#
# "obj"    : Object name or label.
# "folder" : Directory of the calibrated and aligned images.
# "core"   : Directory of the OASIS rendered images and s_ and g_ files.
# "aux"    : Directory of auxiliary .dat or .txt files containing important values and .obj Shape Model.
# "prod"   : Directory where products and secondary data are stored.
# "kern"   : Directory of NAIF/SPICE Kernels
# "filter" : filter name.
#
#  NEW: Shape Model Viewer and Imager
#  ==================================
#  In construction
#
#
#  Storing data from OASIS output
#  ==============================
#
#  0. Call "from source import *" into your script
#
#  1. Run OASIS:
#  output pathname : Directory where s_*, g_* and a_* products are stored as zipfile (ZIP).
#  run_oasis(exe=[oasis executable pathname], cfgname = [configuration pathname], out_dir = [output pathname])
#  rename_files(directory = [output pathname], sch_file = [schedule file pathname])
#  zipped([output pathname])
#
#  2. Load s_* files into fast reading format
#  load_s( zip_file=[zip filename],
#          images=[specify images to be loaded], 
#          dpi=2048)
#
#  3. Image registration referenced to OASIS rendered images (step needed in case of offset/rotation):
#  from register.registering import register_OASIS
#  register_OASIS(     references     = [list of a_*.fit images including pathname], 
#                      targets        = [list of PDS images], 
#                      transform_file = [name & pathname of the file containg the transformation matrix],
#                      scale_ref      = (%min flux, %max flux),
#                      scale_target   = (%min flux, %max flux),
#                      trimm          = ([corner_x_start,corner_y_start],[corner_x_end,corner_y_end]), # Optional
#                      r              = integer: aperture for gaussian filtering & degrading, # Optional
#                      iteration      = integer: max number of iteration, 
#                      display        = True/False,
#                      save           = True/False)
#
#  4. Store data into HDF5 table format facet index: {IF, IF_std, inc, emi, phase, phi, npix}
#  store_view_geometry(img_list   = [list of Aligned target images], 
#                       zip_file   = [zip filename],
#                       query      = [query applied beforehand to storing data, ex: "IF>0.0 and IF<0.5 and inc<1.32"],
#                       start      = (obj_pix_min,obj_pix_max), 
#                       stop       = (obj_pix_min,obj_pix_max), 
#                       channel    = [integer])
#
#  5. To load HDF5 tables: 
#  read_hdf([HDF5 file name & pathname])
#
#  6. To reconstruct georeferenced FITS images:
#  Output(kind="2D_oasis").project( par   = [pandas.Series values from HDF5 table], 
#                                   image = [imagename to which values are reframed], 
#                                   label = [prefix])
#
#
#  Photometric Model
#  =================
#
#  Description:
#  Photometric model for resolved small bodies (Lutetia, 67P, Ryugu, Steins, Itokawa,...) with shape models.
#  Calculate the phase curve of each facet and corrects disk contribution for each image.
#  Retrieve the phase function of each facet.
#
#  Shkuratov et al. 2011
#  We split the reflectance behavior in two functions:
#  r(a,b,y) = r0 * f(a) * D(a,b,y)
#
#
#  Phase Functions (source/fit/photfunc.py):
#    Akimov      (named: akimov_phase)
#    Kaasaleinen (named: kaas_phase)
#    Exponential or Schroder (named: schroder_phase)
#    ...
#  
#  Disk Functions (source/fit/photfunc.py):
#    Akimov (akimov_disk or parakimov_disk or empakimov_disk)
#    McEwen (mcewen_disk)
#    Minnaert (minnaert_disk)
#    Lommel-Seeliger (ls_disk)
#    ...
#
#  Hapke Model
#  ===========
#
# Main module for hapke inversion.
#
# Main Functions:
#
# Global Hapke fitting     --> hapke_fit.global_fitting (input: binned cube)
# Individual Hapke fitting --> hapke_fit.facet_fitting  (input: hdf5 store)
#
#
#  Input Files:
#  ============
#
#  s_*, g_* files and *_Aligned images retrieve from shape model simulator and coregistration.
#  The input file must be organized as such:
#            A zip file containing the files above and rename as FACETS_[obj].zip
#            Aligned images: *_[Aligned].fit
#
#
#  HF5 file structure:
#  Photometric parameters are stored in *fit_[obj]_[filter].h5:
#
#  /average_phase_params = Average Phase parameters, depended on the fit phase function.
#  /Aeq          = Equigonal Albedo by image.
#  /disk_coefs   = disk coeficients by image.
#  /disk_name    = disk function name.
#  /disk_albedo  = Global Equigonal Albedo.
#  /phase_albedo = Global Albedo given by the average phase parameters.
#  /residue      = residue between image and A(ph)*disk
#
#  or
#
#  Hapke parameters are stored in hapke_[obj]_[filter].h5:
#
#  Output format:
#  fits, pkl, hdf5 
#
#
#
#########################################################################################
'''

####################################################################################################
############################### IMPORT THIS MODULE TO YOUR PLAY GROUND SCRIPT ######################
####################################################################################################

# Garbage Collector disabled.
#import gc
#gc.disable()
#gc.set_debug(gc.DEBUG_LEAK)

# System
from glob import glob
from os import path, walk, listdir, mkdir, remove, rename, system, name, stat, environ, sep
import warnings
warnings.filterwarnings("ignore")
warnings.simplefilter(action="ignore")

# Optimizations
import pandas as pd
from math import pi

# Load File path
from source.specs import *
home = path.expanduser('~')
obj    = path_file["obj"]
folder = path_file["folder"]
core   = path_file["core"]
aux    = path_file["aux"]    
prod   = path_file["prod"]
fi     = path_file["filter"]
kern   = path_file["kern"]

# Call All!
import source.cythonize
from source.support.angles import *
from source.support.support import *
from source.support.img_utils import *

from source.geo import position as pos
from source.geo.shapemodel import ShapeModel
from source.geo.shapeviewer import Viewer
from source.geo.shapeimager import Imager
from source.geo.store2 import Store, binning, store_shape_patches
from source.model import photmodel

#from source.geo.oasis import oasis, retrieve
import source.fit as fit
import source.geo as geo
import source.model as model
import source.output as output
import source.support as support


#END
