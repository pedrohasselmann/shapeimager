#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__="1.0.0"

__doc__='''
  ############################ STATISTICS ##############################
  ### Filename: statistics.py
  ### Author: Pedro H. A. Hasselmann
  ###
  ### Miscellany of statisitcal methods to support the other modules in PHOTMODEL
  ###
  ######################################################################
'''

######################### GLOBAL IMPORT ####################################
import os
import warnings
warnings.filterwarnings("ignore")
warnings.simplefilter(action = "ignore")

def weighted_std(values, weights, axis=0):
    """
       Return the unbiased weighted standard deviation for Pandas data structure application.

       values, weights -- Numpy ndarrays with the same shape.
    """
    from numpy import average, sqrt, apply_along_axis
    
    N = values.shape[0]
    try:
      avg = average(values, weights=weights, axis=axis)
      variance = average(((values - avg)**2), weights=weights, axis=axis)*(N/(N-1.0))  # Fast and numerically precise
    
    except ZeroDivisionError:
      avg = 0e0
      variance = 0e0
    
    return sqrt(variance)


def h_bin(data):
    '''
       Optimal histogram bin number retrieve.       
    '''
    from numpy import subtract, nanpercentile, nanmax, nanmin, isnan

    IQR = subtract(*nanpercentile(data, [75, 25]))
    h = 2e0 * IQR * data.shape[0]**(-1e0/3)
    
    #print(data.shape[0],(nanmax(data) - nanmin(data))/h, subtract(*percentile(data, [99, 1]))/h)
    
    return int((nanmax(data) - nanmin(data))/h)

def gradient2D(x, y):
   '''
      Direction of the gradient vector.
   '''
   from numpy import gradient, arccos
   
   dx = gradient(x)
   dy = gradient(y)
   
   return arccos(dy-dx)
  
def fisher_information_matrix(X, pars, func):
   '''
     Fisher Information matrix.
     M_{ij} = cov( d(logf[x,par])/d[par], dlogf[X,par']/d[par'] )
     
     X    --> X-axis (N)
     pars --> list of solutions (N, M)
     func --> callable function
   '''
   from numpy import log, cov, matrix, array, gradient, sqrt, matrix, atleast_2d
   from scipy.linalg import det, solve
   
   fx = array([func(X,*p) for p in pars]).T
   #print('fx', fx.shape)
   dx = matrix(gradient(pars, axis=0)).I
   #print('dx',dx.shape)
   df = matrix(gradient(log(fx), axis=1))
   #print('df',df.shape)

   
   # Alternative application
   # J --> jacobian
   # Sigma -->  inverse of variance of the parameters
   #fisher = (jac.T).dot(solve(1e0/var, jac, sym_pos=True, check_finite=True))
   #fisher = atleast_2d(fisher)
   #print(fisher)
   
   M = dx*df.T
  
   return cov(M), fx



###########################
### BAYESIAN STATISTICS ###
###########################

# Bootstrap sample estimation
def bootstrap(data, num_samples, statistical_func, alpha):
  '''
     Returns bootstrap estimate of 100.0*(1-alpha) CI for statistic.
     
     Parameters
     ==========
     
     data: numpy.array
     num_samples: tuple (int, int) --> numbers of samples and resamples
     statistical_func: python function (ex.: np.std, np.mean,...)
     alpha: float
  '''
  from astropy.stats import bootstrap
  from numpy import sort
  from numpy.random import randint
  
  n = len(data)
  idx = randint(0, n, size=num_samples)
  samples = data[idx]
  stat = sort(statistical_func(samples, 1))
  
  return stat[int((alpha/2.0)*num_samples[0])], stat[int((1-alpha/2.0)*num_samples[0])]
  

# END
