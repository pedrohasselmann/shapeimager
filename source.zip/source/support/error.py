# -*- coding: utf-8 -*-
#!/usr/bin/python

# Escrevendo em python3 e usando python2.6:
from __future__ import print_function, unicode_literals, absolute_import, division

__version__="1.0.0"

__doc__='''
  ######################## ERROR ESTIMATION TOOL ##################################
  ### Author: Pedro H. A. Hasselmann
  ### Last modified: March, 2016
  ### 
  ### Miscellany of function for analytically and numerically estimating spectrophotomeric errors.
  ###
  #################################################################################
'''

# Global Import
from numpy import array, degrees, radians, cos, sin, sqrt, where
from os import path
import warnings
warnings.filterwarnings("ignore")
warnings.simplefilter(action="ignore")


def u_phase(u_r, D):
  '''
    Uncertainty on phase angle.
  '''
  from numpy import arccos
  
  return arccos(1e0 - 0.5*(u_r/D)**2)

##########################
## Disk Function errors ##
##########################

# Lommel-Seeliger error
def u_ls(e, i, u_IF, u_e, u_i):

  '''
     Lommel-Seliger error propagation, relative to IF.
     
     Input
     =====
     e    --> sequence start:stop:step
     i    --> sequence start:stop:step
     u_IF --> relative IF error
     u_e  --> Absolute emergence error
     u_i  --> absolute incidence error
     
  '''

  from numpy import meshgrid

  ev, iv = meshgrid(e,i)

  m0 = cos(iv)
  m1 = cos(ev)
  u_m0 = u_i * sin(iv)
  u_m1 = u_e * sin(ev)
  
  return (2e0*u_IF*(m0+m1)/m0)**2 +  (u_m0**2) * (2e0*m1/(m0**2))**2 + (2e0*u_m1/m0)**2

# Lambert Error
def u_lambert(i, u_IF, u_i):

  '''
     Lambert error propagation, relative to IF.
  '''
  
  m0 = cos(i)
  u_m0 = u_i * sin(i)
  
  return (u_IF/m0)**2 + (u_m0/(m0**2))**2

# Minnaert Error:
def u_minnaert(k, i, e, u_IF, u_i, u_e):

  m0 = cos(i)
  m1 = cos(e)
  u_m0 = u_i * sin(i)
  u_m1 = u_e * sin(e)
  minnaert = (m0**k)*(m1**(k-1e0))
  
  return (u_IF/minnaert)**2 + ((k-1e0)*(m0**(k-2e0)*(m1**(k-2e0)))*u_m0)**2 + ((k-2e0)*(m0**(k-1e0)*(m1**(k-3e0)))*u_m1)**2

def u_mcewen(c, i, e, u_IF, u_i, u_e):

  m0 = cos(i)
  m1 = cos(e)
  u_m0 = u_i * sin(i)
  u_m1 = u_e * sin(e)
  
  return

#################
## FLUX ERRORS ##
#################


#################################
## Tools for estimating errors ##
#################################

'''center_wv = pd.Series(central_filter).loc[['WAC_F13','WAC_F17','NAC_F82']]
u = sqrt(sum((array([0.014,0.07,0.04])*1e3/center_wv)**2))   # hc
print('hc error: ',u)
u = sqrt(sum((array([0.008,0.0087,0.001])*1e3/center_wv)**2))    # SSA
print('SSA error: ',u)
u = sqrt(sum((array([0.026,0.025,0.003])*1e3/center_wv)**2))    # gsca
print('gsca error: ',u)
u = sqrt(sum((array([0.0027,0.017,0.033])*1e3/center_wv)**2))    # Bc
print('Bc error: ',u)
u = sqrt(sum((array([0.0015,0.013,0.002])*1e3/center_wv)**2))    # Bs
print('Bs error: ',u)
u = sqrt(sum((array([0.00017,0.0013,0.0007])*1e3/center_wv)**2))    # hs
print('hs error: ',u)
u = sqrt(sum((array([0.09,0.11,0.054])*1e3/center_wv)**2))    # theta
print('theta error: ',u)
'''

def slope_error(flux=0.1, error_ratio={'WAC_F13':0.1,'WAC_F17':0.02,'NAC_F82':0.02}):
  from output.spectra import central_filter#, error_ratio
  from math import sqrt, factorial
  import pandas as pd
  
  center_wv = pd.Series(central_filter).loc[['WAC_F13','WAC_F17','NAC_F82']]
  
  delta_error = 0
  wv = center_wv.values
  for f in center_wv.keys():
    sign = pd.Series(1, index=center_wv.keys())
    sign[wv > center_wv[f]] = -1
    
    delta = sign*abs(center_wv - center_wv[f])/1e3
    delta_error += sum(flux * error_ratio[f]/delta[delta != 0])**2
  
  N = len(wv)*len(wv)
  
  return 100*sqrt(delta_error)/N

def phase_reddening_error(R1=2.1, R2=5.8, delta_ph=20, e1=1.92, e2=1.35, e_ph=0.05):
  from math import sqrt
    
  term1 = (1e0/delta_ph**2)*(e1**2 + e2**2)
  term2 = (2e0*((R1 - R2)/delta_ph**2)*e_ph**2)**2
  
  return sqrt(term1 + term2)

def interpolate_error(x, diff, nbin=150, kind_interp='linear'):
   '''
     Estimate interpolation for errors with respect to x.
     x    : 1d array, x-axis
     diff : 1d array, differences, y-axis
     nbin : int, gridsize
     knid_interp : str, kind of interp1d
   '''
   from numpy import isnan, array, std
   from scipy.stats import binned_statistic
   from scipy.interpolate import interp1d
   import matplotlib.pyplot as plt

   plt.hexbin(x[~isnan(diff)], diff[~isnan(diff)],gridsize=nbin, mincnt=1)

   bin, edges, locator = binned_statistic(x[~isnan(diff)], diff[~isnan(diff)], bins=nbin, statistic="median")
   dev, edges, locator = binned_statistic(x[~isnan(diff)], diff[~isnan(diff)], bins=nbin, statistic=std)

   # Central point of the bin
   #print('edges: ', edges)
   central = array([sum(edges[i:i+2])/2.0 for i in xrange(0, len(edges))])[:-1]

   error_func = interp1d(central[~isnan(bin)], bin[~isnan(bin)], kind=kind_interp, fill_value=0e0)
   std_func = interp1d(central[~isnan(bin)], dev[~isnan(bin)], kind=kind_interp, fill_value=0e0)
   print('limits: ', central[~isnan(bin)].min(),central[~isnan(bin)].max())

   plt.errorbar(central, bin, yerr=dev, marker='o',color='r')
   
   return std_func, error_func, plt

# END
