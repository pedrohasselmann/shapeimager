#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__="1.0.0"

__doc__='''
  ############################ SUPPORT FUNCTIONS ##############################
  ### Filename: make_metakernel.py
  ### Author: Prasanna Deshapriya, LESIA-OBSPM-France
  ###
  ### make .mk for NAIF SPICE library
  ###
  #############################################################################
'''
from source import *

def RetrieveLocalList(folder,ext):
   import os
   pwd = os.getcwd()
   destination = kern
   os.chdir(path.join(home,kern,folder))
   files = (os.popen('ls *.'+ext).read()).split('\n')
   files.remove(files[-1])
   os.chdir(pwd)
   return folder,files


def make(drlist=['ik','iak','lsk','sclk','fk','pck','ck','spk','dsk'],
         exts = ['ti','ti','tls','tsc','tf','tpc','bc','bsp','bds','dsk'] #extensions
         ):
  from datetime import datetime
  
  Fname = datetime.utcnow().strftime("%Y-%m-%d")
  Path_symbol = 'P'

  with open(path.join(home,kern,'orex_'+Fname+'.mk'),'w') as f:
    f.write('\\begintext\n')
    f.write('Automatically created meta kernel on '+Fname+' using support.make_metakernel.make()\n')
    f.write('\\begindata\n')
    f.write('PATH_VALUES = (\n')
    f.write("    '"+path.join(home,kern)+"',\n")
    f.write(')\n')
    f.write('PATH_SYMBOLS = (\n')
    f.write("    '"+Path_symbol+"'\n")
    f.write(')\n')
    f.write('\n')
    f.write('KERNELS_TO_LOAD = (\n')
    #f.write("'"+'$'+Path_symbol+'/ik/orx_ovirs_v00.ti')
    for folder,ext in zip(drlist,exts):
        fi = RetrieveLocalList(folder,ext)
        for name in fi[1][:]:
            f.write("    '"+'$'+Path_symbol+'/'+fi[0]+'/'+name+"',\n")
            #print(fi[0],fi[1])
    f.write('\n')
    f.write(')\n')

