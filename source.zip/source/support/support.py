#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__="1.0.0"

__doc__='''
  ############################ SUPPORT FUNCTIONS ##############################
  ### Filename: support.py
  ### Author: Pedro H. A. Hasselmann
  ###
  ### Miscellany of function to support the other modules in PHOTMODEL
  ###
  #############################################################################
'''

########################## Shell Functions ##################################

def config(filename, section):
   import ConfigParser
    
   Config = ConfigParser.ConfigParser()
   Config.read(filename)
    
   option = dict(Config.items(section))
   #for key in option.keys(): option[key] = tuple(map(str.strip, option[key].split("#")))
   return option

def collect(l=50000):
  import gc
  i = 0
  while True:
     if i >= l:
       gc.collect()
       yield 0
       i = 0
     else:    
       yield i
       i += 1

def make_dir(pth):
    import os
    try:
        os.mkdir(pth)
    except OSError:
        pass
    return pth

##################################### Pickle ###########################################

def pickle(filename, *data):
   import cPickle as cpkl
   print(filename)
   output = open(filename+".pkl",'wb')  
   for d in data:
      cpkl.dump(data,output, 2)
   output.close()

def unpickle(filename):
   import cPickle as cpkl
   i = open(filename+".pkl",'rb')  
   rec = cpkl.load(i)
   i.close()
   return rec

def unpickle_buffer(filename):
   import cPickle
   u = cPickle.Unpickler(open(filename+".pkl", 'rb'))
   
   while True:
     try:
       yield u.load()
     except EOFError:
       break

def pickle_function(filename,*func):
   import cloudpickle
   import pickle as pkl
   output = open(filename+".pkl",'wb') 
   for f in func:
      serial = cloudpickle.dumps(func)
      pkl.dump(serial,output)
   output.close()

def unpickle_function(filename):
   import pickle as pkl
   i = open(filename+".pkl",'rb')  
   return pkl.loads(pkl.load(i))

#################### Multiprocessing ####################################
def init_worker():
    import signal
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    
from contextlib import contextmanager
@contextmanager
def poolcontext(*args, **kwargs):
    # https://stackoverflow.com/questions/5442910/python-multiprocessing-pool-map-for-multiple-arguments/5442981
    import multiprocessing as mp
    pool = mp.Pool(*args, **kwargs)
    yield pool
    pool.terminate()


########################
####### TXT FILES ######
########################

def split_list(directory, filename, block, reference='F22'):
  '''
     Split a list of images into equally spaced blocks of image sequences
     
     Parameters
     ==========
     directory
     filename : original filename containing all images in a given folder
     block : int, number of sequences
     reference : image reference (first in the list)
  '''
  from os import path
  from numpy import loadtxt
  home = path.expanduser('~')
  file = loadtxt(path.join(home, directory, filename), dtype=str)
  
  for n, i in enumerate( range(0, len(file), block)):
    chunk = ['{}\n'.format(x) for x in file[i:i+block] ]

    ref = [line for line in chunk if line[-8:-5] == reference]
    print(ref)
    label = ref[0].split('.')
    label = label[0][-13:]+'h'+label[1]
    chunk.remove(ref[0])

    if path.exists(path.join(home, directory, label+'.txt')) is False:   
      out = open(path.join(home, directory, label+'.txt'), 'w')
      out.write(ref[0])
      [out.write(line) for line in chunk]
      out.close()


def cross_lists(col, label=lambda x: x[:28], *lists):
  from numpy import loadtxt
  
  f = list()
  for l in lists:
    f.append( loadtxt(l, dtype=str, usecols=col) )
    f[-1] = map(func, f[-1])
  
  print(f[0])
  common = list(set().intersection(*f))

  print(common)

##########################
## Interpolation Tools ###
##########################

def build_grid(vecs):
  from numpy import empty, hstack
  
  coords = empty(map(len,vecs.values())+[len(vecs.keys())])
  ii = 0
  for k, v in vecs.iteritems():
     s = hstack((len(v), np.ones(len(vecs.keys())-ii-1)))
     vv = v.reshape(s)
     coords[...,ii] = vv
     ii += 1  
  return dict(zip(vecs.keys(), [coords[...,i] for i in xrange(ii)]))
     
def grid_interp(func,**axis):
  '''
     Build a multi-dimensional grid evaluating the function at different variables.
  '''
  from numpy import linspace, meshgrid, float32
  import scipy.interpolate as interp
  from collections import OrderedDict as odict
  
  ndm = dict()
  for lbl, x in axis.iteritems(): ndm[lbl] = linspace(*x) 
  grid = dict(zip(axis.keys(),meshgrid(*ndm.values(), indexing='ij')))
  evaluation = func(**grid).astype(float32)
  
  print(axis)
  #print(evaluation.shape)

  function = interp.RegularGridInterpolator(ndm.values(), evaluation, 
            bounds_error=False, fill_value=1.0, method='linear')
  
  return ndm, grid, evaluation, function

################################# MISC. FUNCTIONS ##########################################

def group_iter(iterator, n=2, strict=False):
    """ 
    Transforms a sequence of values into a sequence of n-tuples.
    e.g. [1, 2, 3, 4, ...] => [(1, 2), (3, 4), ...] (when n == 2)
    If strict, then it will raise ValueError if there is a group of fewer
    than n items at the end of the sequence. 
    """
    from collections import deque
    accumulator = deque()
    for item in iterator:
        accumulator.append(item)
        if len(accumulator) == n: # tested as fast as separate counter
            yield tuple(accumulator)
            accumulator = deque() # tested faster than accumulator[:] = []
            # and tested as fast as re-using one list object
    if strict and len(accumulator) != 0:
        raise ValueError("Leftover values")


##### in N dimensional search ####
# https://stackoverflow.com/questions/16216078/test-for-membership-in-a-2d-numpy-array
def _asvoid(arr):
    """
    Input array must be c-contiguous.
    
    Based on http://stackoverflow.com/a/16973510/190597
    View the array as dtype np.void (bytes). The items along the last axis are
    viewed as one value. This allows comparisons to be performed on the entire row.
    """
    from numpy import issubdtype, dtype, void, floating
    #arr = np.ascontiguousarray(arr)
    if issubdtype(arr.dtype, floating):
        """ Care needs to be taken here since
        np.array([-0.]).view(np.void) != np.array([0.]).view(np.void)
        Adding 0. converts -0. to 0.
        """
        arr += 0.
    return arr.view(dtype((void, arr.dtype.itemsize * arr.shape[-1])))


def inNd(a, b, assume_unique=False, invert=False):
    from numpy import in1d
    a = _asvoid(a)
    b = _asvoid(b)
    return in1d(a, b, assume_unique, invert)

# END
